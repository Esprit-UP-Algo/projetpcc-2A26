#ifndef PERSONNEL_H
#define PERSONNEL_H

#include <QString>
#include <QSqlQuery>

class Personnel
{
public:

    Personnel();


    Personnel(int id, QString nom, QString prenom, QString mail, QString telephone, QString role, QString sexe);


    bool ajouter();


    QSqlQuery afficher();

    bool supprimer(int id);


private:

    int id;
    QString nom;
    QString prenom;
    QString mail;
    QString telephone;
    QString role;
    QString sexe;
};

#endif // PERSONNEL_H
