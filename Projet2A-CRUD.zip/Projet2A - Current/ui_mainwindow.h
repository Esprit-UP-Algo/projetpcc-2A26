/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.7.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCalendarWidget>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QFrame *frame_6;
    QToolButton *toolButton_fourn1;
    QToolButton *toolButton_prod1;
    QToolButton *toolButton_person1;
    QToolButton *toolButton_loc1;
    QToolButton *toolButton_client1;
    QLabel *label_4;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QStackedWidget *stackedWidget;
    QWidget *personnel;
    QStackedWidget *stackedWidget_3;
    QWidget *page;
    QFrame *frame;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *headerLayout;
    QLabel *lblListeClients;
    QHBoxLayout *searchLayout;
    QFrame *frame_7;
    QToolButton *toolButton_6;
    QToolButton *toolButton_7;
    QToolButton *toolButton_8;
    QToolButton *toolButton_9;
    QToolButton *toolButton_10;
    QLineEdit *searchLineEdit;
    QPushButton *btnRechercher;
    QComboBox *comboProfession;
    QPushButton *btnFilter;
    QPushButton *btnExporter;
    QHBoxLayout *headerLayout_2;
    QTableWidget *tablePersonnel;
    QHBoxLayout *actionButtonsLayout;
    QPushButton *btnListePersonnel_3;
    QPushButton *btnAjouterPersonnel_3;
    QLabel *label_16;
    QFrame *frame_2;
    QWidget *page_2;
    QWidget *page_6;
    QFrame *frameFicheClient;
    QLabel *lblFicheClient;
    QLabel *lblid;
    QLabel *lblnom;
    QLabel *lblprenom;
    QLabel *lbltel;
    QLabel *label_8;
    QLabel *lblbirth;
    QWidget *layoutWidget;
    QHBoxLayout *ajouterActionLayout;
    QPushButton *btnConfirmer;
    QPushButton *btnAnnuler;
    QLineEdit *lineEditNom;
    QLineEdit *lineEditPhone;
    QLineEdit *lineEditDateNaissance;
    QLineEdit *lineEditID;
    QLineEdit *lineEditPrenom;
    QComboBox *comboSexe;
    QLabel *lblnom_2;
    QLineEdit *lineEditNom_2;
    QPushButton *btnAjouterClient_2;
    QPushButton *btnListeClients_2;
    QWidget *locaux;
    QStackedWidget *stackedWidget_2;
    QWidget *page_3;
    QFrame *frame_3;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *headerLayout_3;
    QLabel *lblListeClients_2;
    QHBoxLayout *searchLayout_2;
    QFrame *frame_9;
    QToolButton *toolButton_11;
    QToolButton *toolButton_12;
    QToolButton *toolButton_13;
    QToolButton *toolButton_14;
    QToolButton *toolButton_15;
    QLineEdit *searchLineEdit_2;
    QPushButton *btnRechercher_2;
    QComboBox *comboProfession_2;
    QPushButton *btnFilter_2;
    QPushButton *btnExporter_2;
    QHBoxLayout *headerLayout_4;
    QHBoxLayout *actionButtonsLayout_2;
    QTableWidget *tablePersonnel_2;
    QPushButton *btnListePersonnel_4;
    QPushButton *btnAjouterPersonnel_4;
    QFrame *frame_4;
    QLabel *label_19;
    QLabel *label_26;
    QFrame *frame_15;
    QWidget *page_4;
    QWidget *page_5;
    QFrame *frameFicheClient_2;
    QLabel *lblFicheClient_2;
    QLabel *lblid_2;
    QLabel *lblnom_3;
    QLabel *lblprenom_2;
    QLabel *lbltel_2;
    QLabel *lblbirth_2;
    QWidget *layoutWidget_2;
    QHBoxLayout *ajouterActionLayout_2;
    QPushButton *btnConfirmer_2;
    QPushButton *btnAnnuler_2;
    QLineEdit *lineEditNom_3;
    QLineEdit *lineEditPhone_2;
    QLineEdit *lineEditDateNaissance_2;
    QLineEdit *lineEditID_2;
    QLineEdit *lineEditPrenom_2;
    QLabel *label_9;
    QLineEdit *lineEditDateNaissance_3;
    QLabel *label_27;
    QCheckBox *checkOld;
    QCheckBox *checkNew;
    QCheckBox *checkVIP;
    QLabel *label;
    QPushButton *btnAjouterClient_3;
    QPushButton *btnListeClients_3;
    QWidget *clients;
    QStackedWidget *stackedWidget_4;
    QWidget *page_7;
    QFrame *frame_5;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *headerLayout_5;
    QLabel *lblListeClients_3;
    QHBoxLayout *searchLayout_3;
    QFrame *frame_8;
    QToolButton *toolButton_17;
    QToolButton *toolButton_18;
    QToolButton *toolButton_19;
    QToolButton *toolButton_20;
    QToolButton *toolButton_21;
    QLineEdit *searchLineEdit_3;
    QPushButton *btnRechercher_3;
    QComboBox *comboProfession_3;
    QPushButton *btnFilter_3;
    QPushButton *btnExporter_3;
    QHBoxLayout *headerLayout_6;
    QTableWidget *tableClients;
    QHBoxLayout *actionButtonsLayout_3;
    QPushButton *btnListeClients_4;
    QPushButton *btnAjouterClient_4;
    QLabel *label_17;
    QLabel *label_2;
    QLabel *label_3;
    QWidget *page_8;
    QWidget *page_9;
    QFrame *frameFicheClient_3;
    QLabel *lblFicheClient_3;
    QLabel *lblid_3;
    QLabel *lblnom_4;
    QLabel *lblprenom_3;
    QLabel *lbltel_3;
    QLabel *label_10;
    QLabel *lblbirth_3;
    QLabel *lblstatus;
    QWidget *layoutWidget_3;
    QHBoxLayout *ajouterActionLayout_3;
    QPushButton *btnConfirmer_3;
    QPushButton *btnAnnuler_3;
    QLineEdit *lineEditNom_4;
    QLineEdit *lineEditPhone_3;
    QCheckBox *checkNew_2;
    QLineEdit *lineEditDateNaissance_4;
    QLineEdit *lineEditID_3;
    QLineEdit *lineEditPrenom_3;
    QCheckBox *checkOld_2;
    QCheckBox *checkVIP_2;
    QComboBox *comboSexe_2;
    QLabel *lblphoto;
    QTextEdit *textEdit;
    QLabel *lblordo;
    QLabel *lblpdp;
    QLabel *lblordo_2;
    QListWidget *listachatrecents;
    QPushButton *btnAjouterClient_5;
    QPushButton *btnListeClients_5;
    QWidget *fournisseur;
    QStackedWidget *stackedWidget_5;
    QWidget *page_11;
    QFrame *frame_10;
    QHBoxLayout *horizontalLayout_4;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *headerLayout_7;
    QLabel *lblListeClients_4;
    QHBoxLayout *searchLayout_4;
    QFrame *frame_11;
    QToolButton *toolButton_22;
    QToolButton *toolButton_23;
    QToolButton *toolButton_24;
    QToolButton *toolButton_25;
    QToolButton *toolButton_26;
    QLineEdit *searchLineEdit_4;
    QPushButton *btnRechercher_4;
    QComboBox *comboProfession_4;
    QPushButton *btnFilter_4;
    QPushButton *btnExporter_4;
    QHBoxLayout *headerLayout_8;
    QTableWidget *tableClients_2;
    QHBoxLayout *actionButtonsLayout_4;
    QPushButton *btnListeClients_6;
    QPushButton *btnAjouterClient_6;
    QLabel *label_28;
    QFrame *frame_16;
    QWidget *page_12;
    QWidget *page_13;
    QFrame *frameFicheClient_4;
    QLabel *lblFicheClient_4;
    QLabel *lblid_4;
    QLabel *lblnom_5;
    QLabel *lblprenom_4;
    QLabel *lbltel_4;
    QLabel *lblbirth_4;
    QWidget *layoutWidget_4;
    QHBoxLayout *ajouterActionLayout_4;
    QPushButton *btnConfirmer_4;
    QPushButton *btnAnnuler_4;
    QLineEdit *lineEditNom_5;
    QLineEdit *lineEditPhone_4;
    QLineEdit *lineEditDateNaissance_5;
    QLineEdit *lineEditID_4;
    QComboBox *comboCategorie;
    QLineEdit *lineEditPhone_5;
    QLabel *lbltel_5;
    QPushButton *btnAjouterClient_7;
    QPushButton *btnListeClients_7;
    QWidget *produits;
    QStackedWidget *stackedWidget_6;
    QWidget *page_10;
    QFrame *frame_12;
    QHBoxLayout *horizontalLayout_5;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *headerLayout_9;
    QLabel *lblListeClients_5;
    QHBoxLayout *searchLayout_5;
    QFrame *frame_13;
    QToolButton *toolButton_27;
    QToolButton *toolButton_28;
    QToolButton *toolButton_29;
    QToolButton *toolButton_30;
    QToolButton *toolButton_31;
    QLineEdit *searchLineEdit_5;
    QPushButton *btnRechercher_5;
    QComboBox *comboProfession_5;
    QPushButton *btnFilter_5;
    QPushButton *btnExporter_5;
    QHBoxLayout *headerLayout_10;
    QTableWidget *tablePersonnel_3;
    QHBoxLayout *actionButtonsLayout_5;
    QPushButton *btnListePersonnel_5;
    QPushButton *btnAjouterPersonnel_5;
    QLabel *label_32;
    QFrame *frame_18;
    QLabel *label_33;
    QLabel *label_34;
    QWidget *page_14;
    QWidget *page_15;
    QWidget *page_16;
    QPushButton *btnAjouterClient_8;
    QPushButton *btnListeClients_8;
    QLabel *label_29;
    QFrame *frame_17;
    QLabel *label_18;
    QTableWidget *tableWidget;
    QFrame *frameFicheClient_5;
    QLabel *lblFicheClient_5;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_24;
    QLabel *label_25;
    QLabel *label_30;
    QWidget *layoutWidget_5;
    QHBoxLayout *ajouterActionLayout_5;
    QPushButton *btnAnnuler_5;
    QPushButton *btnConfirmer_5;
    QLineEdit *lineEditNom_6;
    QLineEdit *lineEditDateNaissance_6;
    QLineEdit *lineEditID_5;
    QLineEdit *lineEditPrenom_4;
    QLabel *label_31;
    QLabel *label_35;
    QLineEdit *lineEditDateNaissance_7;
    QSpinBox *spinBox;
    QSpinBox *spinBox_2;
    QCalendarWidget *calendarWidget;
    QLabel *label_36;
    QDateEdit *dateEdit;
    QFrame *line;
    QComboBox *comboProfession_6;
    QLabel *label_37;
    QComboBox *comboProfession_7;
    QComboBox *comboProfession_8;
    QLabel *label_38;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1499, 875);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        frame_6 = new QFrame(centralwidget);
        frame_6->setObjectName("frame_6");
        frame_6->setGeometry(QRect(0, 60, 191, 751));
        frame_6->setToolTipDuration(0);
        frame_6->setStyleSheet(QString::fromUtf8("QFrame {\n"
"    border: none;\n"
"    background-color: white;\n"
"    border-top-right-radius: 70px;   /* \360\237\221\210 arrondi seulement coin haut droit */\n"
"    border-top-left-radius: 0px;\n"
"    border-bottom-left-radius: 0px;\n"
"    border-bottom-right-radius: 0px;\n"
"\n"
"	\n"
"	background-color: rgb(0, 0, 124);\n"
"}\n"
""));
        frame_6->setFrameShape(QFrame::Shape::StyledPanel);
        frame_6->setFrameShadow(QFrame::Shadow::Raised);
        toolButton_fourn1 = new QToolButton(frame_6);
        toolButton_fourn1->setObjectName("toolButton_fourn1");
        toolButton_fourn1->setGeometry(QRect(10, 290, 171, 41));
        toolButton_fourn1->setStyleSheet(QString::fromUtf8("QToolButton {\n"
"    border: none;\n"
"    border-radius: 20px;\n"
"    color: white;\n"
"    padding: 12px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #6c5ce7, stop:1 #a29bfe);\n"
"    font-weight: bold;\n"
"    font-size: 14px;\n"
"}\n"
"QToolButton:hover {\n"
"font-size: 20px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #a29bfe, stop:1 #fd79a8);\n"
"}"));
        toolButton_prod1 = new QToolButton(frame_6);
        toolButton_prod1->setObjectName("toolButton_prod1");
        toolButton_prod1->setGeometry(QRect(10, 350, 171, 41));
        toolButton_prod1->setStyleSheet(QString::fromUtf8("QToolButton {\n"
"    border: none;\n"
"    border-radius: 20px;\n"
"    color: white;\n"
"    padding: 12px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #6c5ce7, stop:1 #a29bfe);\n"
"    font-weight: bold;\n"
"    font-size: 14px;\n"
"}\n"
"QToolButton:hover {\n"
"font-size: 20px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #a29bfe, stop:1 #fd79a8);\n"
"}"));
        toolButton_person1 = new QToolButton(frame_6);
        toolButton_person1->setObjectName("toolButton_person1");
        toolButton_person1->setGeometry(QRect(10, 410, 171, 41));
        toolButton_person1->setStyleSheet(QString::fromUtf8("QToolButton {\n"
"    border: none;\n"
"    border-radius: 20px;\n"
"    color: white;\n"
"    padding: 12px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #6c5ce7, stop:1 #a29bfe);\n"
"    font-weight: bold;\n"
"    font-size: 14px;\n"
"}\n"
"QToolButton:hover {\n"
"font-size: 20px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #a29bfe, stop:1 #fd79a8);\n"
"}"));
        toolButton_loc1 = new QToolButton(frame_6);
        toolButton_loc1->setObjectName("toolButton_loc1");
        toolButton_loc1->setGeometry(QRect(10, 470, 171, 41));
        toolButton_loc1->setStyleSheet(QString::fromUtf8("QToolButton {\n"
"    border: none;\n"
"    border-radius: 20px;\n"
"    color: white;\n"
"    padding: 12px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #6c5ce7, stop:1 #a29bfe);\n"
"    font-weight: bold;\n"
"    font-size: 14px;\n"
"}\n"
"QToolButton:hover {\n"
"font-size: 20px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #a29bfe, stop:1 #fd79a8);\n"
"}"));
        toolButton_client1 = new QToolButton(frame_6);
        toolButton_client1->setObjectName("toolButton_client1");
        toolButton_client1->setGeometry(QRect(10, 230, 171, 41));
        toolButton_client1->setStyleSheet(QString::fromUtf8("QToolButton {\n"
"    border: none;\n"
"    border-radius: 20px;\n"
"    color: white;\n"
"    padding: 12px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #6c5ce7, stop:1 #a29bfe);\n"
"    font-weight: bold;\n"
"    font-size: 14px;\n"
"}\n"
"QToolButton:hover {\n"
"font-size: 20px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #a29bfe, stop:1 #fd79a8);\n"
"}"));
        label_4 = new QLabel(frame_6);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(20, 30, 141, 111));
        label_4->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/tt.png")));
        label_11 = new QLabel(frame_6);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(30, 230, 31, 41));
        label_11->setStyleSheet(QString::fromUtf8("background-color : #6c5ce7;"));
        label_11->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/client-removebg-preview.png")));
        label_12 = new QLabel(frame_6);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(30, 290, 31, 41));
        label_12->setStyleSheet(QString::fromUtf8("background-color : #6c5ce7;"));
        label_12->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/fournisseurs-removebg-preview.png")));
        label_13 = new QLabel(frame_6);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(30, 350, 31, 41));
        label_13->setStyleSheet(QString::fromUtf8("background-color : #6c5ce7;"));
        label_13->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/produit-removebg-preview.png")));
        label_14 = new QLabel(frame_6);
        label_14->setObjectName("label_14");
        label_14->setGeometry(QRect(30, 410, 31, 41));
        label_14->setStyleSheet(QString::fromUtf8("background-color : #6c5ce7;"));
        label_14->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/personal-removebg-preview.png")));
        label_15 = new QLabel(frame_6);
        label_15->setObjectName("label_15");
        label_15->setGeometry(QRect(30, 470, 31, 41));
        label_15->setStyleSheet(QString::fromUtf8("background-color : #6c5ce7;"));
        label_15->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/locaux-removebg-preview.png")));
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName("stackedWidget");
        stackedWidget->setGeometry(QRect(-1, -1, 1501, 821));
        personnel = new QWidget();
        personnel->setObjectName("personnel");
        stackedWidget_3 = new QStackedWidget(personnel);
        stackedWidget_3->setObjectName("stackedWidget_3");
        stackedWidget_3->setGeometry(QRect(0, 10, 1481, 811));
        stackedWidget_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        page = new QWidget();
        page->setObjectName("page");
        frame = new QFrame(page);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(210, 70, 961, 691));
        frame->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        frame->setFrameShape(QFrame::Shape::StyledPanel);
        frame->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout = new QHBoxLayout(frame);
        horizontalLayout->setObjectName("horizontalLayout");
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName("verticalLayout");
        headerLayout = new QHBoxLayout();
        headerLayout->setObjectName("headerLayout");

        verticalLayout->addLayout(headerLayout);

        lblListeClients = new QLabel(frame);
        lblListeClients->setObjectName("lblListeClients");
        QFont font;
        font.setPointSize(16);
        font.setBold(true);
        lblListeClients->setFont(font);
        lblListeClients->setStyleSheet(QString::fromUtf8("color:#2d224c;font-weight:bold;margin:16px 0 8px 0;\n"
"background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(lblListeClients);

        searchLayout = new QHBoxLayout();
        searchLayout->setObjectName("searchLayout");
        frame_7 = new QFrame(frame);
        frame_7->setObjectName("frame_7");
        frame_7->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 124);; border-radius:20px;"));
        frame_7->setFrameShape(QFrame::Shape::StyledPanel);
        frame_7->setFrameShadow(QFrame::Shadow::Raised);
        toolButton_6 = new QToolButton(frame_7);
        toolButton_6->setObjectName("toolButton_6");
        toolButton_6->setGeometry(QRect(20, 240, 141, 41));
        toolButton_6->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_7 = new QToolButton(frame_7);
        toolButton_7->setObjectName("toolButton_7");
        toolButton_7->setGeometry(QRect(20, 300, 141, 41));
        toolButton_7->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_8 = new QToolButton(frame_7);
        toolButton_8->setObjectName("toolButton_8");
        toolButton_8->setGeometry(QRect(20, 360, 141, 41));
        toolButton_8->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_9 = new QToolButton(frame_7);
        toolButton_9->setObjectName("toolButton_9");
        toolButton_9->setGeometry(QRect(20, 420, 141, 41));
        toolButton_9->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_10 = new QToolButton(frame_7);
        toolButton_10->setObjectName("toolButton_10");
        toolButton_10->setGeometry(QRect(20, 180, 141, 41));
        toolButton_10->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }\n"
""));

        searchLayout->addWidget(frame_7);

        searchLineEdit = new QLineEdit(frame);
        searchLineEdit->setObjectName("searchLineEdit");
        searchLineEdit->setStyleSheet(QString::fromUtf8("background-color:#f5f6fa;border-radius:10px;padding:8px 16px;font-size:14px;color :black;"));

        searchLayout->addWidget(searchLineEdit);

        btnRechercher = new QPushButton(frame);
        btnRechercher->setObjectName("btnRechercher");

        searchLayout->addWidget(btnRechercher);

        comboProfession = new QComboBox(frame);
        comboProfession->addItem(QString());
        comboProfession->addItem(QString());
        comboProfession->addItem(QString());
        comboProfession->addItem(QString());
        comboProfession->addItem(QString());
        comboProfession->setObjectName("comboProfession");
        comboProfession->setAcceptDrops(false);
        comboProfession->setStyleSheet(QString::fromUtf8("background-color:#f5f6fa;border-radius:10px;padding:8px 16px;font-size:14px;color :black; "));
        comboProfession->setEditable(false);

        searchLayout->addWidget(comboProfession);

        btnFilter = new QPushButton(frame);
        btnFilter->setObjectName("btnFilter");
        btnFilter->setStyleSheet(QString::fromUtf8("background-color:#a55eea;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:14px;"));

        searchLayout->addWidget(btnFilter);

        btnExporter = new QPushButton(frame);
        btnExporter->setObjectName("btnExporter");
        btnExporter->setStyleSheet(QString::fromUtf8("background-color:#a55eea;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:14px;"));

        searchLayout->addWidget(btnExporter);


        verticalLayout->addLayout(searchLayout);

        headerLayout_2 = new QHBoxLayout();
        headerLayout_2->setObjectName("headerLayout_2");
        tablePersonnel = new QTableWidget(frame);
        if (tablePersonnel->columnCount() < 10)
            tablePersonnel->setColumnCount(10);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tablePersonnel->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tablePersonnel->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tablePersonnel->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tablePersonnel->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tablePersonnel->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tablePersonnel->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tablePersonnel->setHorizontalHeaderItem(6, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tablePersonnel->setHorizontalHeaderItem(7, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tablePersonnel->setHorizontalHeaderItem(8, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tablePersonnel->setHorizontalHeaderItem(9, __qtablewidgetitem9);
        if (tablePersonnel->rowCount() < 8)
            tablePersonnel->setRowCount(8);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tablePersonnel->setItem(0, 0, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tablePersonnel->setItem(0, 1, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tablePersonnel->setItem(0, 2, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tablePersonnel->setItem(0, 3, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tablePersonnel->setItem(0, 9, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tablePersonnel->setItem(1, 0, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tablePersonnel->setItem(1, 1, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tablePersonnel->setItem(1, 2, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tablePersonnel->setItem(1, 3, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tablePersonnel->setItem(2, 0, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        tablePersonnel->setItem(2, 1, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        tablePersonnel->setItem(2, 2, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        tablePersonnel->setItem(2, 3, __qtablewidgetitem22);
        tablePersonnel->setObjectName("tablePersonnel");
        tablePersonnel->setStyleSheet(QString::fromUtf8("/* --- Style du conteneur principal de la table --- */\n"
"QTableWidget {\n"
"    background-color: white;\n"
"    color: rgb(0, 0, 0);\n"
"    border-radius: 10px;\n"
"    gridline-color: #dfe6e9;\n"
"    border: 1px solid #dfe6e9;\n"
"}\n"
"\n"
"/* --- Style de l'en-t\303\252te --- */\n"
"QHeaderView::section {\n"
"    background-color: #2d224c;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    padding: 8px;\n"
"    border: none;\n"
"}\n"
"\n"
"/* --- Style pour chaque cellule (SANS PADDING) --- */\n"
"QTableWidget::item {\n"
"    border-bottom: 1px solid #dfe6e9;\n"
"}\n"
"\n"
"/* --- Style pour les cellules s\303\251lectionn\303\251es --- */\n"
"QTableWidget::item:selected {\n"
"    background-color: #a29bfe;\n"
"    color: white;\n"
"}"));

        headerLayout_2->addWidget(tablePersonnel);


        verticalLayout->addLayout(headerLayout_2);

        actionButtonsLayout = new QHBoxLayout();
        actionButtonsLayout->setObjectName("actionButtonsLayout");

        verticalLayout->addLayout(actionButtonsLayout);


        horizontalLayout->addLayout(verticalLayout);

        btnListePersonnel_3 = new QPushButton(page);
        btnListePersonnel_3->setObjectName("btnListePersonnel_3");
        btnListePersonnel_3->setGeometry(QRect(290, 10, 341, 41));
        btnListePersonnel_3->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        btnAjouterPersonnel_3 = new QPushButton(page);
        btnAjouterPersonnel_3->setObjectName("btnAjouterPersonnel_3");
        btnAjouterPersonnel_3->setGeometry(QRect(650, 10, 331, 41));
        btnAjouterPersonnel_3->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        label_16 = new QLabel(page);
        label_16->setObjectName("label_16");
        label_16->setGeometry(QRect(1220, 20, 211, 31));
        label_16->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 0, 127);\n"
"border-color: rgb(0, 0, 255);"));
        label_16->setAlignment(Qt::AlignmentFlag::AlignCenter);
        frame_2 = new QFrame(page);
        frame_2->setObjectName("frame_2");
        frame_2->setGeometry(QRect(1220, 50, 211, 711));
        frame_2->setStyleSheet(QString::fromUtf8("background-color: rgb(186, 186, 186);"));
        frame_2->setFrameShape(QFrame::Shape::StyledPanel);
        frame_2->setFrameShadow(QFrame::Shadow::Raised);
        stackedWidget_3->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName("page_2");
        stackedWidget_3->addWidget(page_2);
        page_6 = new QWidget();
        page_6->setObjectName("page_6");
        frameFicheClient = new QFrame(page_6);
        frameFicheClient->setObjectName("frameFicheClient");
        frameFicheClient->setGeometry(QRect(220, 80, 841, 641));
        frameFicheClient->setStyleSheet(QString::fromUtf8("border:2px solid #a55eea; border-radius:20px; background-color:#f5f6fa;\n"
"border-color: rgb(0, 0, 127);"));
        lblFicheClient = new QLabel(frameFicheClient);
        lblFicheClient->setObjectName("lblFicheClient");
        lblFicheClient->setGeometry(QRect(180, 70, 481, 68));
        QFont font1;
        font1.setPointSize(18);
        font1.setBold(true);
        lblFicheClient->setFont(font1);
        lblFicheClient->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 127);"));
        lblFicheClient->setFrameShape(QFrame::Shape::StyledPanel);
        lblFicheClient->setFrameShadow(QFrame::Shadow::Raised);
        lblFicheClient->setAlignment(Qt::AlignmentFlag::AlignCenter);
        lblid = new QLabel(frameFicheClient);
        lblid->setObjectName("lblid");
        lblid->setGeometry(QRect(210, 180, 91, 20));
        lblid->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lblnom = new QLabel(frameFicheClient);
        lblnom->setObjectName("lblnom");
        lblnom->setGeometry(QRect(210, 230, 91, 20));
        lblnom->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lblprenom = new QLabel(frameFicheClient);
        lblprenom->setObjectName("lblprenom");
        lblprenom->setGeometry(QRect(210, 280, 91, 20));
        lblprenom->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lbltel = new QLabel(frameFicheClient);
        lbltel->setObjectName("lbltel");
        lbltel->setGeometry(QRect(210, 380, 91, 20));
        lbltel->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        label_8 = new QLabel(frameFicheClient);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(210, 480, 91, 20));
        label_8->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lblbirth = new QLabel(frameFicheClient);
        lblbirth->setObjectName("lblbirth");
        lblbirth->setGeometry(QRect(210, 430, 91, 21));
        lblbirth->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        layoutWidget = new QWidget(frameFicheClient);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(570, 550, 240, 42));
        ajouterActionLayout = new QHBoxLayout(layoutWidget);
        ajouterActionLayout->setObjectName("ajouterActionLayout");
        ajouterActionLayout->setContentsMargins(0, 0, 0, 0);
        btnConfirmer = new QPushButton(layoutWidget);
        btnConfirmer->setObjectName("btnConfirmer");

        ajouterActionLayout->addWidget(btnConfirmer);

        btnAnnuler = new QPushButton(layoutWidget);
        btnAnnuler->setObjectName("btnAnnuler");

        ajouterActionLayout->addWidget(btnAnnuler);

        lineEditNom = new QLineEdit(frameFicheClient);
        lineEditNom->setObjectName("lineEditNom");
        lineEditNom->setGeometry(QRect(370, 230, 251, 26));
        lineEditNom->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditPhone = new QLineEdit(frameFicheClient);
        lineEditPhone->setObjectName("lineEditPhone");
        lineEditPhone->setGeometry(QRect(370, 380, 251, 26));
        lineEditPhone->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditDateNaissance = new QLineEdit(frameFicheClient);
        lineEditDateNaissance->setObjectName("lineEditDateNaissance");
        lineEditDateNaissance->setGeometry(QRect(370, 430, 251, 26));
        lineEditDateNaissance->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditID = new QLineEdit(frameFicheClient);
        lineEditID->setObjectName("lineEditID");
        lineEditID->setGeometry(QRect(370, 180, 251, 26));
        lineEditID->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditPrenom = new QLineEdit(frameFicheClient);
        lineEditPrenom->setObjectName("lineEditPrenom");
        lineEditPrenom->setGeometry(QRect(370, 280, 251, 26));
        lineEditPrenom->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        comboSexe = new QComboBox(frameFicheClient);
        comboSexe->addItem(QString());
        comboSexe->addItem(QString());
        comboSexe->setObjectName("comboSexe");
        comboSexe->setGeometry(QRect(370, 480, 251, 31));
        lblnom_2 = new QLabel(frameFicheClient);
        lblnom_2->setObjectName("lblnom_2");
        lblnom_2->setGeometry(QRect(210, 330, 91, 20));
        lblnom_2->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lineEditNom_2 = new QLineEdit(frameFicheClient);
        lineEditNom_2->setObjectName("lineEditNom_2");
        lineEditNom_2->setGeometry(QRect(370, 330, 251, 26));
        lineEditNom_2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        btnAjouterClient_2 = new QPushButton(page_6);
        btnAjouterClient_2->setObjectName("btnAjouterClient_2");
        btnAjouterClient_2->setGeometry(QRect(650, 10, 331, 41));
        btnAjouterClient_2->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        btnListeClients_2 = new QPushButton(page_6);
        btnListeClients_2->setObjectName("btnListeClients_2");
        btnListeClients_2->setGeometry(QRect(290, 10, 341, 41));
        btnListeClients_2->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        stackedWidget_3->addWidget(page_6);
        stackedWidget->addWidget(personnel);
        locaux = new QWidget();
        locaux->setObjectName("locaux");
        stackedWidget_2 = new QStackedWidget(locaux);
        stackedWidget_2->setObjectName("stackedWidget_2");
        stackedWidget_2->setGeometry(QRect(-10, 50, 1481, 811));
        stackedWidget_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        page_3 = new QWidget();
        page_3->setObjectName("page_3");
        frame_3 = new QFrame(page_3);
        frame_3->setObjectName("frame_3");
        frame_3->setGeometry(QRect(210, 70, 921, 531));
        frame_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        frame_3->setFrameShape(QFrame::Shape::StyledPanel);
        frame_3->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_2 = new QHBoxLayout(frame_3);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName("verticalLayout_2");
        headerLayout_3 = new QHBoxLayout();
        headerLayout_3->setObjectName("headerLayout_3");

        verticalLayout_2->addLayout(headerLayout_3);

        lblListeClients_2 = new QLabel(frame_3);
        lblListeClients_2->setObjectName("lblListeClients_2");
        lblListeClients_2->setFont(font);
        lblListeClients_2->setStyleSheet(QString::fromUtf8("color:#2d224c;font-weight:bold;margin:16px 0 8px 0;\n"
"background-color: rgb(255, 255, 255);"));

        verticalLayout_2->addWidget(lblListeClients_2);

        searchLayout_2 = new QHBoxLayout();
        searchLayout_2->setObjectName("searchLayout_2");
        frame_9 = new QFrame(frame_3);
        frame_9->setObjectName("frame_9");
        frame_9->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 124);; border-radius:20px;"));
        frame_9->setFrameShape(QFrame::Shape::StyledPanel);
        frame_9->setFrameShadow(QFrame::Shadow::Raised);
        toolButton_11 = new QToolButton(frame_9);
        toolButton_11->setObjectName("toolButton_11");
        toolButton_11->setGeometry(QRect(20, 240, 141, 41));
        toolButton_11->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_12 = new QToolButton(frame_9);
        toolButton_12->setObjectName("toolButton_12");
        toolButton_12->setGeometry(QRect(20, 300, 141, 41));
        toolButton_12->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_13 = new QToolButton(frame_9);
        toolButton_13->setObjectName("toolButton_13");
        toolButton_13->setGeometry(QRect(20, 360, 141, 41));
        toolButton_13->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_14 = new QToolButton(frame_9);
        toolButton_14->setObjectName("toolButton_14");
        toolButton_14->setGeometry(QRect(20, 420, 141, 41));
        toolButton_14->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_15 = new QToolButton(frame_9);
        toolButton_15->setObjectName("toolButton_15");
        toolButton_15->setGeometry(QRect(20, 180, 141, 41));
        toolButton_15->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }\n"
""));

        searchLayout_2->addWidget(frame_9);

        searchLineEdit_2 = new QLineEdit(frame_3);
        searchLineEdit_2->setObjectName("searchLineEdit_2");
        searchLineEdit_2->setStyleSheet(QString::fromUtf8("background-color:#f5f6fa;border-radius:10px;padding:8px 16px;font-size:14px;color :black;"));

        searchLayout_2->addWidget(searchLineEdit_2);

        btnRechercher_2 = new QPushButton(frame_3);
        btnRechercher_2->setObjectName("btnRechercher_2");
        btnRechercher_2->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"	background-color: rgb(169, 94, 255);\n"
"    background-color: #a55eea;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 10px;\n"
"    padding: 5px 16px;\n"
"    font-size: 14px;\n"
"    border: 2px solid #a55eea;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color:#c494ff;\n"
"    border: 2px solid #a55eea;\n"
"}\n"
""));

        searchLayout_2->addWidget(btnRechercher_2);

        comboProfession_2 = new QComboBox(frame_3);
        comboProfession_2->addItem(QString());
        comboProfession_2->addItem(QString());
        comboProfession_2->addItem(QString());
        comboProfession_2->addItem(QString());
        comboProfession_2->setObjectName("comboProfession_2");
        comboProfession_2->setAcceptDrops(false);
        comboProfession_2->setStyleSheet(QString::fromUtf8("background-color:#f5f6fa;border-radius:10px;padding:8px 16px;font-size:14px;color :black; "));
        comboProfession_2->setEditable(false);

        searchLayout_2->addWidget(comboProfession_2);

        btnFilter_2 = new QPushButton(frame_3);
        btnFilter_2->setObjectName("btnFilter_2");
        btnFilter_2->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"	background-color: rgb(169, 94, 255);\n"
"    background-color: #a55eea;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 10px;\n"
"    padding: 5px 16px;\n"
"    font-size: 14px;\n"
"    border: 2px solid #a55eea;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color:#c494ff;\n"
"    border: 2px solid #a55eea;\n"
"}\n"
""));

        searchLayout_2->addWidget(btnFilter_2);

        btnExporter_2 = new QPushButton(frame_3);
        btnExporter_2->setObjectName("btnExporter_2");
        btnExporter_2->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	background-color: rgb(169, 94, 255);\n"
"    background-color: #a55eea;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 10px;\n"
"    padding: 5px 16px;\n"
"    font-size: 14px;\n"
"    border: 2px solid #a55eea;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color:#c494ff;\n"
"    border: 2px solid #a55eea;\n"
"}\n"
""));

        searchLayout_2->addWidget(btnExporter_2);


        verticalLayout_2->addLayout(searchLayout_2);

        headerLayout_4 = new QHBoxLayout();
        headerLayout_4->setObjectName("headerLayout_4");

        verticalLayout_2->addLayout(headerLayout_4);

        actionButtonsLayout_2 = new QHBoxLayout();
        actionButtonsLayout_2->setObjectName("actionButtonsLayout_2");
        tablePersonnel_2 = new QTableWidget(frame_3);
        if (tablePersonnel_2->columnCount() < 8)
            tablePersonnel_2->setColumnCount(8);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        tablePersonnel_2->setHorizontalHeaderItem(0, __qtablewidgetitem23);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        tablePersonnel_2->setHorizontalHeaderItem(1, __qtablewidgetitem24);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        tablePersonnel_2->setHorizontalHeaderItem(2, __qtablewidgetitem25);
        QTableWidgetItem *__qtablewidgetitem26 = new QTableWidgetItem();
        tablePersonnel_2->setHorizontalHeaderItem(3, __qtablewidgetitem26);
        QTableWidgetItem *__qtablewidgetitem27 = new QTableWidgetItem();
        tablePersonnel_2->setHorizontalHeaderItem(4, __qtablewidgetitem27);
        QTableWidgetItem *__qtablewidgetitem28 = new QTableWidgetItem();
        tablePersonnel_2->setHorizontalHeaderItem(5, __qtablewidgetitem28);
        QTableWidgetItem *__qtablewidgetitem29 = new QTableWidgetItem();
        tablePersonnel_2->setHorizontalHeaderItem(6, __qtablewidgetitem29);
        QTableWidgetItem *__qtablewidgetitem30 = new QTableWidgetItem();
        tablePersonnel_2->setHorizontalHeaderItem(7, __qtablewidgetitem30);
        if (tablePersonnel_2->rowCount() < 8)
            tablePersonnel_2->setRowCount(8);
        QTableWidgetItem *__qtablewidgetitem31 = new QTableWidgetItem();
        __qtablewidgetitem31->setCheckState(Qt::Unchecked);
        tablePersonnel_2->setItem(0, 0, __qtablewidgetitem31);
        QTableWidgetItem *__qtablewidgetitem32 = new QTableWidgetItem();
        tablePersonnel_2->setItem(0, 1, __qtablewidgetitem32);
        QTableWidgetItem *__qtablewidgetitem33 = new QTableWidgetItem();
        tablePersonnel_2->setItem(0, 2, __qtablewidgetitem33);
        QTableWidgetItem *__qtablewidgetitem34 = new QTableWidgetItem();
        tablePersonnel_2->setItem(0, 7, __qtablewidgetitem34);
        QTableWidgetItem *__qtablewidgetitem35 = new QTableWidgetItem();
        __qtablewidgetitem35->setCheckState(Qt::Unchecked);
        tablePersonnel_2->setItem(1, 0, __qtablewidgetitem35);
        QTableWidgetItem *__qtablewidgetitem36 = new QTableWidgetItem();
        tablePersonnel_2->setItem(1, 1, __qtablewidgetitem36);
        QTableWidgetItem *__qtablewidgetitem37 = new QTableWidgetItem();
        tablePersonnel_2->setItem(1, 2, __qtablewidgetitem37);
        QTableWidgetItem *__qtablewidgetitem38 = new QTableWidgetItem();
        __qtablewidgetitem38->setCheckState(Qt::Unchecked);
        tablePersonnel_2->setItem(2, 0, __qtablewidgetitem38);
        QTableWidgetItem *__qtablewidgetitem39 = new QTableWidgetItem();
        tablePersonnel_2->setItem(2, 1, __qtablewidgetitem39);
        QTableWidgetItem *__qtablewidgetitem40 = new QTableWidgetItem();
        tablePersonnel_2->setItem(2, 2, __qtablewidgetitem40);
        QTableWidgetItem *__qtablewidgetitem41 = new QTableWidgetItem();
        __qtablewidgetitem41->setCheckState(Qt::Unchecked);
        tablePersonnel_2->setItem(3, 0, __qtablewidgetitem41);
        QTableWidgetItem *__qtablewidgetitem42 = new QTableWidgetItem();
        __qtablewidgetitem42->setCheckState(Qt::Unchecked);
        tablePersonnel_2->setItem(4, 0, __qtablewidgetitem42);
        QTableWidgetItem *__qtablewidgetitem43 = new QTableWidgetItem();
        __qtablewidgetitem43->setCheckState(Qt::Unchecked);
        tablePersonnel_2->setItem(5, 0, __qtablewidgetitem43);
        QTableWidgetItem *__qtablewidgetitem44 = new QTableWidgetItem();
        __qtablewidgetitem44->setCheckState(Qt::Unchecked);
        tablePersonnel_2->setItem(6, 0, __qtablewidgetitem44);
        QTableWidgetItem *__qtablewidgetitem45 = new QTableWidgetItem();
        __qtablewidgetitem45->setCheckState(Qt::Unchecked);
        tablePersonnel_2->setItem(7, 0, __qtablewidgetitem45);
        tablePersonnel_2->setObjectName("tablePersonnel_2");
        tablePersonnel_2->setStyleSheet(QString::fromUtf8("/* --- Style du conteneur principal de la table --- */\n"
"QTableWidget {\n"
"    background-color: white;\n"
"    color: rgb(0, 0, 0);\n"
"    border-radius: 10px;\n"
"    gridline-color: #dfe6e9;\n"
"    border: 1px solid #dfe6e9;\n"
"}\n"
"\n"
"/* --- Style de l'en-t\303\252te --- */\n"
"QHeaderView::section {\n"
"    background-color: #2d224c;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    padding: 8px;\n"
"    border: none;\n"
"}\n"
"\n"
"/* --- Style pour chaque cellule (SANS PADDING) --- */\n"
"QTableWidget::item {\n"
"    border-bottom: 1px solid #dfe6e9;\n"
"}\n"
"\n"
"/* --- Style pour les cellules s\303\251lectionn\303\251es --- */\n"
"QTableWidget::item:selected {\n"
"    background-color: #a29bfe;\n"
"    color: white;\n"
"}"));

        actionButtonsLayout_2->addWidget(tablePersonnel_2);


        verticalLayout_2->addLayout(actionButtonsLayout_2);


        horizontalLayout_2->addLayout(verticalLayout_2);

        btnListePersonnel_4 = new QPushButton(page_3);
        btnListePersonnel_4->setObjectName("btnListePersonnel_4");
        btnListePersonnel_4->setGeometry(QRect(290, 10, 341, 41));
        btnListePersonnel_4->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        btnAjouterPersonnel_4 = new QPushButton(page_3);
        btnAjouterPersonnel_4->setObjectName("btnAjouterPersonnel_4");
        btnAjouterPersonnel_4->setGeometry(QRect(650, 10, 331, 41));
        btnAjouterPersonnel_4->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        frame_4 = new QFrame(page_3);
        frame_4->setObjectName("frame_4");
        frame_4->setGeometry(QRect(210, 600, 921, 161));
        frame_4->setFrameShape(QFrame::Shape::StyledPanel);
        frame_4->setFrameShadow(QFrame::Shadow::Raised);
        label_19 = new QLabel(frame_4);
        label_19->setObjectName("label_19");
        label_19->setGeometry(QRect(0, 0, 921, 251));
        label_19->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/maps.jpg")));
        label_19->setScaledContents(true);
        label_19->setWordWrap(true);
        label_19->setOpenExternalLinks(true);
        label_26 = new QLabel(page_3);
        label_26->setObjectName("label_26");
        label_26->setGeometry(QRect(1150, 20, 211, 31));
        label_26->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 0, 127);\n"
"border-color: rgb(0, 0, 255);"));
        label_26->setAlignment(Qt::AlignmentFlag::AlignCenter);
        frame_15 = new QFrame(page_3);
        frame_15->setObjectName("frame_15");
        frame_15->setGeometry(QRect(1150, 50, 211, 711));
        frame_15->setStyleSheet(QString::fromUtf8("background-color: rgb(186, 186, 186);"));
        frame_15->setFrameShape(QFrame::Shape::StyledPanel);
        frame_15->setFrameShadow(QFrame::Shadow::Raised);
        stackedWidget_2->addWidget(page_3);
        page_4 = new QWidget();
        page_4->setObjectName("page_4");
        stackedWidget_2->addWidget(page_4);
        page_5 = new QWidget();
        page_5->setObjectName("page_5");
        frameFicheClient_2 = new QFrame(page_5);
        frameFicheClient_2->setObjectName("frameFicheClient_2");
        frameFicheClient_2->setGeometry(QRect(260, 80, 1081, 631));
        frameFicheClient_2->setStyleSheet(QString::fromUtf8("border:2px solid #a55eea; border-radius:20px; background-color:#f5f6fa;\n"
"border-color: rgb(0, 0, 127);"));
        lblFicheClient_2 = new QLabel(frameFicheClient_2);
        lblFicheClient_2->setObjectName("lblFicheClient_2");
        lblFicheClient_2->setGeometry(QRect(280, 30, 481, 68));
        lblFicheClient_2->setFont(font1);
        lblFicheClient_2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 127);"));
        lblFicheClient_2->setFrameShape(QFrame::Shape::StyledPanel);
        lblFicheClient_2->setFrameShadow(QFrame::Shadow::Raised);
        lblFicheClient_2->setAlignment(Qt::AlignmentFlag::AlignCenter);
        lblid_2 = new QLabel(frameFicheClient_2);
        lblid_2->setObjectName("lblid_2");
        lblid_2->setGeometry(QRect(70, 160, 121, 20));
        lblid_2->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lblnom_3 = new QLabel(frameFicheClient_2);
        lblnom_3->setObjectName("lblnom_3");
        lblnom_3->setGeometry(QRect(70, 210, 121, 20));
        lblnom_3->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lblprenom_2 = new QLabel(frameFicheClient_2);
        lblprenom_2->setObjectName("lblprenom_2");
        lblprenom_2->setGeometry(QRect(70, 260, 121, 20));
        lblprenom_2->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lbltel_2 = new QLabel(frameFicheClient_2);
        lbltel_2->setObjectName("lbltel_2");
        lbltel_2->setGeometry(QRect(70, 310, 121, 20));
        lbltel_2->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lblbirth_2 = new QLabel(frameFicheClient_2);
        lblbirth_2->setObjectName("lblbirth_2");
        lblbirth_2->setGeometry(QRect(70, 360, 121, 21));
        lblbirth_2->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        layoutWidget_2 = new QWidget(frameFicheClient_2);
        layoutWidget_2->setObjectName("layoutWidget_2");
        layoutWidget_2->setGeometry(QRect(780, 540, 254, 43));
        ajouterActionLayout_2 = new QHBoxLayout(layoutWidget_2);
        ajouterActionLayout_2->setObjectName("ajouterActionLayout_2");
        ajouterActionLayout_2->setContentsMargins(0, 0, 0, 0);
        btnConfirmer_2 = new QPushButton(layoutWidget_2);
        btnConfirmer_2->setObjectName("btnConfirmer_2");

        ajouterActionLayout_2->addWidget(btnConfirmer_2);

        btnAnnuler_2 = new QPushButton(layoutWidget_2);
        btnAnnuler_2->setObjectName("btnAnnuler_2");

        ajouterActionLayout_2->addWidget(btnAnnuler_2);

        lineEditNom_3 = new QLineEdit(frameFicheClient_2);
        lineEditNom_3->setObjectName("lineEditNom_3");
        lineEditNom_3->setGeometry(QRect(230, 210, 251, 26));
        lineEditNom_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditPhone_2 = new QLineEdit(frameFicheClient_2);
        lineEditPhone_2->setObjectName("lineEditPhone_2");
        lineEditPhone_2->setGeometry(QRect(230, 310, 251, 26));
        lineEditPhone_2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditDateNaissance_2 = new QLineEdit(frameFicheClient_2);
        lineEditDateNaissance_2->setObjectName("lineEditDateNaissance_2");
        lineEditDateNaissance_2->setGeometry(QRect(230, 360, 251, 26));
        lineEditDateNaissance_2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditID_2 = new QLineEdit(frameFicheClient_2);
        lineEditID_2->setObjectName("lineEditID_2");
        lineEditID_2->setGeometry(QRect(230, 160, 251, 26));
        lineEditID_2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditPrenom_2 = new QLineEdit(frameFicheClient_2);
        lineEditPrenom_2->setObjectName("lineEditPrenom_2");
        lineEditPrenom_2->setGeometry(QRect(230, 260, 251, 26));
        lineEditPrenom_2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_9 = new QLabel(frameFicheClient_2);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(70, 410, 121, 20));
        label_9->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lineEditDateNaissance_3 = new QLineEdit(frameFicheClient_2);
        lineEditDateNaissance_3->setObjectName("lineEditDateNaissance_3");
        lineEditDateNaissance_3->setGeometry(QRect(230, 410, 251, 26));
        lineEditDateNaissance_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_27 = new QLabel(frameFicheClient_2);
        label_27->setObjectName("label_27");
        label_27->setGeometry(QRect(70, 460, 121, 20));
        label_27->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        checkOld = new QCheckBox(frameFicheClient_2);
        checkOld->setObjectName("checkOld");
        checkOld->setGeometry(QRect(230, 460, 101, 24));
        checkOld->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 88, 127);"));
        checkNew = new QCheckBox(frameFicheClient_2);
        checkNew->setObjectName("checkNew");
        checkNew->setGeometry(QRect(340, 460, 81, 24));
        checkNew->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 88, 127);"));
        checkVIP = new QCheckBox(frameFicheClient_2);
        checkVIP->setObjectName("checkVIP");
        checkVIP->setGeometry(QRect(430, 460, 71, 24));
        checkVIP->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 88, 127);"));
        label = new QLabel(frameFicheClient_2);
        label->setObjectName("label");
        label->setGeometry(QRect(650, 150, 241, 171));
        label->setStyleSheet(QString::fromUtf8("image: url(:/icons/imgloc.jpg);"));
        label->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/qq.jpg")));
        label->setScaledContents(true);
        btnAjouterClient_3 = new QPushButton(page_5);
        btnAjouterClient_3->setObjectName("btnAjouterClient_3");
        btnAjouterClient_3->setGeometry(QRect(650, 10, 331, 41));
        btnAjouterClient_3->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        btnListeClients_3 = new QPushButton(page_5);
        btnListeClients_3->setObjectName("btnListeClients_3");
        btnListeClients_3->setGeometry(QRect(290, 10, 341, 41));
        btnListeClients_3->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        stackedWidget_2->addWidget(page_5);
        stackedWidget->addWidget(locaux);
        clients = new QWidget();
        clients->setObjectName("clients");
        stackedWidget_4 = new QStackedWidget(clients);
        stackedWidget_4->setObjectName("stackedWidget_4");
        stackedWidget_4->setGeometry(QRect(10, 0, 1481, 811));
        stackedWidget_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        page_7 = new QWidget();
        page_7->setObjectName("page_7");
        frame_5 = new QFrame(page_7);
        frame_5->setObjectName("frame_5");
        frame_5->setGeometry(QRect(210, 70, 921, 691));
        frame_5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        frame_5->setFrameShape(QFrame::Shape::StyledPanel);
        frame_5->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_3 = new QHBoxLayout(frame_5);
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName("verticalLayout_3");
        headerLayout_5 = new QHBoxLayout();
        headerLayout_5->setObjectName("headerLayout_5");

        verticalLayout_3->addLayout(headerLayout_5);

        lblListeClients_3 = new QLabel(frame_5);
        lblListeClients_3->setObjectName("lblListeClients_3");
        lblListeClients_3->setFont(font);
        lblListeClients_3->setStyleSheet(QString::fromUtf8("color:#2d224c;font-weight:bold;margin:16px 0 8px 0;\n"
"background-color: rgb(255, 255, 255);"));

        verticalLayout_3->addWidget(lblListeClients_3);

        searchLayout_3 = new QHBoxLayout();
        searchLayout_3->setObjectName("searchLayout_3");
        frame_8 = new QFrame(frame_5);
        frame_8->setObjectName("frame_8");
        frame_8->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 124);; border-radius:20px;"));
        frame_8->setFrameShape(QFrame::Shape::StyledPanel);
        frame_8->setFrameShadow(QFrame::Shadow::Raised);
        toolButton_17 = new QToolButton(frame_8);
        toolButton_17->setObjectName("toolButton_17");
        toolButton_17->setGeometry(QRect(20, 240, 141, 41));
        toolButton_17->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_18 = new QToolButton(frame_8);
        toolButton_18->setObjectName("toolButton_18");
        toolButton_18->setGeometry(QRect(20, 300, 141, 41));
        toolButton_18->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_19 = new QToolButton(frame_8);
        toolButton_19->setObjectName("toolButton_19");
        toolButton_19->setGeometry(QRect(20, 360, 141, 41));
        toolButton_19->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_20 = new QToolButton(frame_8);
        toolButton_20->setObjectName("toolButton_20");
        toolButton_20->setGeometry(QRect(20, 420, 141, 41));
        toolButton_20->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_21 = new QToolButton(frame_8);
        toolButton_21->setObjectName("toolButton_21");
        toolButton_21->setGeometry(QRect(20, 180, 141, 41));
        toolButton_21->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }\n"
""));

        searchLayout_3->addWidget(frame_8);

        searchLineEdit_3 = new QLineEdit(frame_5);
        searchLineEdit_3->setObjectName("searchLineEdit_3");
        searchLineEdit_3->setStyleSheet(QString::fromUtf8("background-color:#f5f6fa;border-radius:10px;padding:8px 16px;font-size:14px;color :black;"));

        searchLayout_3->addWidget(searchLineEdit_3);

        btnRechercher_3 = new QPushButton(frame_5);
        btnRechercher_3->setObjectName("btnRechercher_3");

        searchLayout_3->addWidget(btnRechercher_3);

        comboProfession_3 = new QComboBox(frame_5);
        comboProfession_3->addItem(QString());
        comboProfession_3->setObjectName("comboProfession_3");
        comboProfession_3->setStyleSheet(QString::fromUtf8("background-color:#f5f6fa;border-radius:10px;padding:8px 16px;font-size:14px;color :black; "));
        comboProfession_3->setEditable(false);

        searchLayout_3->addWidget(comboProfession_3);

        btnFilter_3 = new QPushButton(frame_5);
        btnFilter_3->setObjectName("btnFilter_3");
        btnFilter_3->setStyleSheet(QString::fromUtf8("background-color:#a55eea;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:14px;"));

        searchLayout_3->addWidget(btnFilter_3);

        btnExporter_3 = new QPushButton(frame_5);
        btnExporter_3->setObjectName("btnExporter_3");
        btnExporter_3->setStyleSheet(QString::fromUtf8("background-color:#a55eea;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:14px;"));

        searchLayout_3->addWidget(btnExporter_3);


        verticalLayout_3->addLayout(searchLayout_3);

        headerLayout_6 = new QHBoxLayout();
        headerLayout_6->setObjectName("headerLayout_6");
        tableClients = new QTableWidget(frame_5);
        if (tableClients->columnCount() < 9)
            tableClients->setColumnCount(9);
        QTableWidgetItem *__qtablewidgetitem46 = new QTableWidgetItem();
        tableClients->setHorizontalHeaderItem(0, __qtablewidgetitem46);
        QTableWidgetItem *__qtablewidgetitem47 = new QTableWidgetItem();
        tableClients->setHorizontalHeaderItem(1, __qtablewidgetitem47);
        QTableWidgetItem *__qtablewidgetitem48 = new QTableWidgetItem();
        tableClients->setHorizontalHeaderItem(2, __qtablewidgetitem48);
        QTableWidgetItem *__qtablewidgetitem49 = new QTableWidgetItem();
        tableClients->setHorizontalHeaderItem(3, __qtablewidgetitem49);
        QTableWidgetItem *__qtablewidgetitem50 = new QTableWidgetItem();
        tableClients->setHorizontalHeaderItem(4, __qtablewidgetitem50);
        QTableWidgetItem *__qtablewidgetitem51 = new QTableWidgetItem();
        tableClients->setHorizontalHeaderItem(5, __qtablewidgetitem51);
        QTableWidgetItem *__qtablewidgetitem52 = new QTableWidgetItem();
        tableClients->setHorizontalHeaderItem(6, __qtablewidgetitem52);
        QTableWidgetItem *__qtablewidgetitem53 = new QTableWidgetItem();
        tableClients->setHorizontalHeaderItem(7, __qtablewidgetitem53);
        QTableWidgetItem *__qtablewidgetitem54 = new QTableWidgetItem();
        tableClients->setHorizontalHeaderItem(8, __qtablewidgetitem54);
        if (tableClients->rowCount() < 8)
            tableClients->setRowCount(8);
        QTableWidgetItem *__qtablewidgetitem55 = new QTableWidgetItem();
        __qtablewidgetitem55->setCheckState(Qt::Checked);
        tableClients->setItem(0, 0, __qtablewidgetitem55);
        QTableWidgetItem *__qtablewidgetitem56 = new QTableWidgetItem();
        tableClients->setItem(0, 1, __qtablewidgetitem56);
        QTableWidgetItem *__qtablewidgetitem57 = new QTableWidgetItem();
        tableClients->setItem(0, 2, __qtablewidgetitem57);
        QTableWidgetItem *__qtablewidgetitem58 = new QTableWidgetItem();
        tableClients->setItem(0, 3, __qtablewidgetitem58);
        QTableWidgetItem *__qtablewidgetitem59 = new QTableWidgetItem();
        tableClients->setItem(0, 4, __qtablewidgetitem59);
        QTableWidgetItem *__qtablewidgetitem60 = new QTableWidgetItem();
        tableClients->setItem(0, 5, __qtablewidgetitem60);
        QTableWidgetItem *__qtablewidgetitem61 = new QTableWidgetItem();
        tableClients->setItem(0, 6, __qtablewidgetitem61);
        QTableWidgetItem *__qtablewidgetitem62 = new QTableWidgetItem();
        tableClients->setItem(0, 7, __qtablewidgetitem62);
        QTableWidgetItem *__qtablewidgetitem63 = new QTableWidgetItem();
        __qtablewidgetitem63->setCheckState(Qt::Checked);
        tableClients->setItem(1, 0, __qtablewidgetitem63);
        QTableWidgetItem *__qtablewidgetitem64 = new QTableWidgetItem();
        tableClients->setItem(1, 1, __qtablewidgetitem64);
        QTableWidgetItem *__qtablewidgetitem65 = new QTableWidgetItem();
        tableClients->setItem(1, 2, __qtablewidgetitem65);
        QTableWidgetItem *__qtablewidgetitem66 = new QTableWidgetItem();
        tableClients->setItem(1, 3, __qtablewidgetitem66);
        QTableWidgetItem *__qtablewidgetitem67 = new QTableWidgetItem();
        tableClients->setItem(1, 4, __qtablewidgetitem67);
        QTableWidgetItem *__qtablewidgetitem68 = new QTableWidgetItem();
        tableClients->setItem(1, 5, __qtablewidgetitem68);
        QTableWidgetItem *__qtablewidgetitem69 = new QTableWidgetItem();
        tableClients->setItem(1, 6, __qtablewidgetitem69);
        QTableWidgetItem *__qtablewidgetitem70 = new QTableWidgetItem();
        tableClients->setItem(1, 7, __qtablewidgetitem70);
        QTableWidgetItem *__qtablewidgetitem71 = new QTableWidgetItem();
        __qtablewidgetitem71->setCheckState(Qt::Checked);
        tableClients->setItem(2, 0, __qtablewidgetitem71);
        QTableWidgetItem *__qtablewidgetitem72 = new QTableWidgetItem();
        tableClients->setItem(2, 1, __qtablewidgetitem72);
        QTableWidgetItem *__qtablewidgetitem73 = new QTableWidgetItem();
        tableClients->setItem(2, 2, __qtablewidgetitem73);
        QTableWidgetItem *__qtablewidgetitem74 = new QTableWidgetItem();
        tableClients->setItem(2, 3, __qtablewidgetitem74);
        QTableWidgetItem *__qtablewidgetitem75 = new QTableWidgetItem();
        tableClients->setItem(2, 4, __qtablewidgetitem75);
        QTableWidgetItem *__qtablewidgetitem76 = new QTableWidgetItem();
        tableClients->setItem(2, 5, __qtablewidgetitem76);
        QTableWidgetItem *__qtablewidgetitem77 = new QTableWidgetItem();
        tableClients->setItem(2, 6, __qtablewidgetitem77);
        QTableWidgetItem *__qtablewidgetitem78 = new QTableWidgetItem();
        tableClients->setItem(2, 7, __qtablewidgetitem78);
        tableClients->setObjectName("tableClients");
        tableClients->setStyleSheet(QString::fromUtf8("/*QHeaderView::section { background-color:#2d224c;color:white;font-weight:bold; } QTableWidget { background-color:white; }*/\n"
"QTableWidget {\n"
"    background-color: white;\n"
"	color: rgb(0, 0, 0);\n"
"    border-radius: 10px;\n"
"    gridline-color: #dfe6e9;\n"
"}\n"
"QHeaderView::section {\n"
"    background-color: #2d224c;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    padding: 8px;\n"
"    border: none;\n"
"}\n"
"QTableWidget::item {\n"
"    padding: 8px;\n"
"    border-bottom: 1px solid #dfe6e9;\n"
"}\n"
"QTableWidget::item:selected {\n"
"    background-color: #a29bfe;\n"
"    color: white;\n"
"}\n"
"image: url(:/new/prefix1/4298bb3a-cb0a-48b6-8f36-19903f2c73d8.png);"));

        headerLayout_6->addWidget(tableClients);


        verticalLayout_3->addLayout(headerLayout_6);

        actionButtonsLayout_3 = new QHBoxLayout();
        actionButtonsLayout_3->setObjectName("actionButtonsLayout_3");

        verticalLayout_3->addLayout(actionButtonsLayout_3);


        horizontalLayout_3->addLayout(verticalLayout_3);

        btnListeClients_4 = new QPushButton(page_7);
        btnListeClients_4->setObjectName("btnListeClients_4");
        btnListeClients_4->setGeometry(QRect(290, 10, 341, 41));
        btnListeClients_4->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        btnAjouterClient_4 = new QPushButton(page_7);
        btnAjouterClient_4->setObjectName("btnAjouterClient_4");
        btnAjouterClient_4->setGeometry(QRect(650, 10, 331, 41));
        btnAjouterClient_4->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        label_17 = new QLabel(page_7);
        label_17->setObjectName("label_17");
        label_17->setGeometry(QRect(1220, 20, 191, 41));
        label_17->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, \n"
"                               stop:0 #41375f, \n"
"                               stop:1 #6c5ce7);\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    font-size: 14px;\n"
"    border-radius: 25px;\n"
"    padding: 10px 30px;\n"
"    border: 2px solid #fd79a8;\n"
"    text-align: center;\n"
"    font-family: 'Arial', sans-serif;\n"
"    letter-spacing: 1px;\n"
"    text-transform: uppercase;\n"
"}"));
        label_2 = new QLabel(page_7);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(1140, 80, 351, 291));
        label_2->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/123.png")));
        label_3 = new QLabel(page_7);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(1140, 400, 331, 311));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/456.png")));
        stackedWidget_4->addWidget(page_7);
        page_8 = new QWidget();
        page_8->setObjectName("page_8");
        stackedWidget_4->addWidget(page_8);
        page_9 = new QWidget();
        page_9->setObjectName("page_9");
        frameFicheClient_3 = new QFrame(page_9);
        frameFicheClient_3->setObjectName("frameFicheClient_3");
        frameFicheClient_3->setGeometry(QRect(260, 80, 1081, 631));
        frameFicheClient_3->setStyleSheet(QString::fromUtf8("border:2px solid #a55eea; border-radius:20px; background-color:#f5f6fa;\n"
"border-color: rgb(0, 0, 127);"));
        lblFicheClient_3 = new QLabel(frameFicheClient_3);
        lblFicheClient_3->setObjectName("lblFicheClient_3");
        lblFicheClient_3->setGeometry(QRect(280, 30, 481, 68));
        lblFicheClient_3->setFont(font1);
        lblFicheClient_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 127);"));
        lblFicheClient_3->setFrameShape(QFrame::Shape::StyledPanel);
        lblFicheClient_3->setFrameShadow(QFrame::Shadow::Raised);
        lblid_3 = new QLabel(frameFicheClient_3);
        lblid_3->setObjectName("lblid_3");
        lblid_3->setGeometry(QRect(70, 160, 91, 20));
        lblid_3->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lblnom_4 = new QLabel(frameFicheClient_3);
        lblnom_4->setObjectName("lblnom_4");
        lblnom_4->setGeometry(QRect(70, 210, 91, 20));
        lblnom_4->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lblprenom_3 = new QLabel(frameFicheClient_3);
        lblprenom_3->setObjectName("lblprenom_3");
        lblprenom_3->setGeometry(QRect(70, 260, 91, 20));
        lblprenom_3->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lbltel_3 = new QLabel(frameFicheClient_3);
        lbltel_3->setObjectName("lbltel_3");
        lbltel_3->setGeometry(QRect(70, 310, 91, 20));
        lbltel_3->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        label_10 = new QLabel(frameFicheClient_3);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(70, 430, 91, 20));
        label_10->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lblbirth_3 = new QLabel(frameFicheClient_3);
        lblbirth_3->setObjectName("lblbirth_3");
        lblbirth_3->setGeometry(QRect(70, 370, 91, 21));
        lblbirth_3->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lblstatus = new QLabel(frameFicheClient_3);
        lblstatus->setObjectName("lblstatus");
        lblstatus->setGeometry(QRect(60, 490, 121, 41));
        lblstatus->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        layoutWidget_3 = new QWidget(frameFicheClient_3);
        layoutWidget_3->setObjectName("layoutWidget_3");
        layoutWidget_3->setGeometry(QRect(790, 560, 240, 42));
        ajouterActionLayout_3 = new QHBoxLayout(layoutWidget_3);
        ajouterActionLayout_3->setObjectName("ajouterActionLayout_3");
        ajouterActionLayout_3->setContentsMargins(0, 0, 0, 0);
        btnConfirmer_3 = new QPushButton(layoutWidget_3);
        btnConfirmer_3->setObjectName("btnConfirmer_3");

        ajouterActionLayout_3->addWidget(btnConfirmer_3);

        btnAnnuler_3 = new QPushButton(layoutWidget_3);
        btnAnnuler_3->setObjectName("btnAnnuler_3");

        ajouterActionLayout_3->addWidget(btnAnnuler_3);

        lineEditNom_4 = new QLineEdit(frameFicheClient_3);
        lineEditNom_4->setObjectName("lineEditNom_4");
        lineEditNom_4->setGeometry(QRect(230, 210, 251, 26));
        lineEditNom_4->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditPhone_3 = new QLineEdit(frameFicheClient_3);
        lineEditPhone_3->setObjectName("lineEditPhone_3");
        lineEditPhone_3->setGeometry(QRect(230, 310, 251, 26));
        lineEditPhone_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        checkNew_2 = new QCheckBox(frameFicheClient_3);
        checkNew_2->setObjectName("checkNew_2");
        checkNew_2->setGeometry(QRect(320, 500, 58, 24));
        checkNew_2->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 88, 127);"));
        lineEditDateNaissance_4 = new QLineEdit(frameFicheClient_3);
        lineEditDateNaissance_4->setObjectName("lineEditDateNaissance_4");
        lineEditDateNaissance_4->setGeometry(QRect(230, 360, 251, 26));
        lineEditDateNaissance_4->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditID_3 = new QLineEdit(frameFicheClient_3);
        lineEditID_3->setObjectName("lineEditID_3");
        lineEditID_3->setGeometry(QRect(230, 160, 251, 26));
        lineEditID_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditPrenom_3 = new QLineEdit(frameFicheClient_3);
        lineEditPrenom_3->setObjectName("lineEditPrenom_3");
        lineEditPrenom_3->setGeometry(QRect(230, 260, 251, 26));
        lineEditPrenom_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        checkOld_2 = new QCheckBox(frameFicheClient_3);
        checkOld_2->setObjectName("checkOld_2");
        checkOld_2->setGeometry(QRect(230, 500, 52, 24));
        checkOld_2->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 88, 127);"));
        checkVIP_2 = new QCheckBox(frameFicheClient_3);
        checkVIP_2->setObjectName("checkVIP_2");
        checkVIP_2->setGeometry(QRect(410, 500, 49, 24));
        checkVIP_2->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 88, 127);"));
        comboSexe_2 = new QComboBox(frameFicheClient_3);
        comboSexe_2->addItem(QString());
        comboSexe_2->addItem(QString());
        comboSexe_2->setObjectName("comboSexe_2");
        comboSexe_2->setGeometry(QRect(230, 420, 251, 31));
        lblphoto = new QLabel(frameFicheClient_3);
        lblphoto->setObjectName("lblphoto");
        lblphoto->setGeometry(QRect(760, 130, 201, 181));
        lblphoto->setStyleSheet(QString::fromUtf8("QLabel#photoClient {\n"
"    border: 3px dashed #6c5ce7;\n"
"    border-radius: 15px;\n"
"    background-color: #f8f9fa;\n"
"    min-width: 150px;\n"
"    min-height: 150px;\n"
"    max-width: 150px;\n"
"    max-height: 150px;\n"
"}\n"
"QLabel#photoClient:hover {\n"
"    border: 3px dashed #fd79a8;\n"
"    background-color: #e9ecef;\n"
"}"));
        lblphoto->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/uplode-removebg-preview.png")));
        textEdit = new QTextEdit(frameFicheClient_3);
        textEdit->setObjectName("textEdit");
        textEdit->setGeometry(QRect(790, 370, 121, 31));
        textEdit->setStyleSheet(QString::fromUtf8("QTextEdit {\n"
"    border: 2px solid #dfe6e9;\n"
"    border-radius: 10px;\n"
"    padding: 10px;\n"
"    background-color: white;\n"
"    font-size: 14px;\n"
"}\n"
"QTextEdit:focus {\n"
"    border: 2px solid #6c5ce7;\n"
"}"));
        lblordo = new QLabel(frameFicheClient_3);
        lblordo->setObjectName("lblordo");
        lblordo->setGeometry(QRect(580, 380, 151, 20));
        lblordo->setStyleSheet(QString::fromUtf8("border-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 127);\n"
""));
        lblpdp = new QLabel(frameFicheClient_3);
        lblpdp->setObjectName("lblpdp");
        lblpdp->setGeometry(QRect(580, 150, 151, 20));
        lblpdp->setStyleSheet(QString::fromUtf8("border-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 127);\n"
""));
        lblordo_2 = new QLabel(frameFicheClient_3);
        lblordo_2->setObjectName("lblordo_2");
        lblordo_2->setGeometry(QRect(580, 440, 151, 20));
        lblordo_2->setStyleSheet(QString::fromUtf8("border-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 127);\n"
""));
        listachatrecents = new QListWidget(frameFicheClient_3);
        listachatrecents->setObjectName("listachatrecents");
        listachatrecents->setGeometry(QRect(790, 430, 201, 91));
        listachatrecents->setStyleSheet(QString::fromUtf8("QListWidget {\n"
"    background-color: white;\n"
"    border: 2px solid #dfe6e9;\n"
"    border-radius: 10px;\n"
"    padding: 10px;\n"
"    font-size: 14px;\n"
"    color: #2d3436;\n"
"}\n"
"QListWidget::item {\n"
"    padding: 8px;\n"
"    border-bottom: 1px solid #dfe6e9;\n"
"}\n"
"QListWidget::item:selected {\n"
"    background-color: #a29bfe;\n"
"    color: white;\n"
"}"));
        btnAjouterClient_5 = new QPushButton(page_9);
        btnAjouterClient_5->setObjectName("btnAjouterClient_5");
        btnAjouterClient_5->setGeometry(QRect(650, 10, 331, 41));
        btnAjouterClient_5->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        btnListeClients_5 = new QPushButton(page_9);
        btnListeClients_5->setObjectName("btnListeClients_5");
        btnListeClients_5->setGeometry(QRect(290, 10, 341, 41));
        btnListeClients_5->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        stackedWidget_4->addWidget(page_9);
        stackedWidget->addWidget(clients);
        fournisseur = new QWidget();
        fournisseur->setObjectName("fournisseur");
        stackedWidget_5 = new QStackedWidget(fournisseur);
        stackedWidget_5->setObjectName("stackedWidget_5");
        stackedWidget_5->setGeometry(QRect(0, 0, 1481, 811));
        stackedWidget_5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        page_11 = new QWidget();
        page_11->setObjectName("page_11");
        frame_10 = new QFrame(page_11);
        frame_10->setObjectName("frame_10");
        frame_10->setGeometry(QRect(210, 70, 921, 691));
        frame_10->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        frame_10->setFrameShape(QFrame::Shape::StyledPanel);
        frame_10->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_4 = new QHBoxLayout(frame_10);
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName("verticalLayout_4");
        headerLayout_7 = new QHBoxLayout();
        headerLayout_7->setObjectName("headerLayout_7");

        verticalLayout_4->addLayout(headerLayout_7);

        lblListeClients_4 = new QLabel(frame_10);
        lblListeClients_4->setObjectName("lblListeClients_4");
        lblListeClients_4->setFont(font);
        lblListeClients_4->setStyleSheet(QString::fromUtf8("color:#2d224c;font-weight:bold;margin:16px 0 8px 0;\n"
"background-color: rgb(255, 255, 255);"));

        verticalLayout_4->addWidget(lblListeClients_4);

        searchLayout_4 = new QHBoxLayout();
        searchLayout_4->setObjectName("searchLayout_4");
        frame_11 = new QFrame(frame_10);
        frame_11->setObjectName("frame_11");
        frame_11->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 124);; border-radius:20px;"));
        frame_11->setFrameShape(QFrame::Shape::StyledPanel);
        frame_11->setFrameShadow(QFrame::Shadow::Raised);
        toolButton_22 = new QToolButton(frame_11);
        toolButton_22->setObjectName("toolButton_22");
        toolButton_22->setGeometry(QRect(20, 240, 141, 41));
        toolButton_22->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_23 = new QToolButton(frame_11);
        toolButton_23->setObjectName("toolButton_23");
        toolButton_23->setGeometry(QRect(20, 300, 141, 41));
        toolButton_23->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_24 = new QToolButton(frame_11);
        toolButton_24->setObjectName("toolButton_24");
        toolButton_24->setGeometry(QRect(20, 360, 141, 41));
        toolButton_24->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_25 = new QToolButton(frame_11);
        toolButton_25->setObjectName("toolButton_25");
        toolButton_25->setGeometry(QRect(20, 420, 141, 41));
        toolButton_25->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_26 = new QToolButton(frame_11);
        toolButton_26->setObjectName("toolButton_26");
        toolButton_26->setGeometry(QRect(20, 180, 141, 41));
        toolButton_26->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }\n"
""));

        searchLayout_4->addWidget(frame_11);

        searchLineEdit_4 = new QLineEdit(frame_10);
        searchLineEdit_4->setObjectName("searchLineEdit_4");
        searchLineEdit_4->setStyleSheet(QString::fromUtf8("background-color:#f5f6fa;border-radius:10px;padding:8px 16px;font-size:14px;color :black;"));

        searchLayout_4->addWidget(searchLineEdit_4);

        btnRechercher_4 = new QPushButton(frame_10);
        btnRechercher_4->setObjectName("btnRechercher_4");

        searchLayout_4->addWidget(btnRechercher_4);

        comboProfession_4 = new QComboBox(frame_10);
        comboProfession_4->addItem(QString());
        comboProfession_4->addItem(QString());
        comboProfession_4->addItem(QString());
        comboProfession_4->setObjectName("comboProfession_4");
        comboProfession_4->setStyleSheet(QString::fromUtf8("background-color:#f5f6fa;border-radius:10px;padding:8px 16px;font-size:14px;color :black; "));
        comboProfession_4->setEditable(false);

        searchLayout_4->addWidget(comboProfession_4);

        btnFilter_4 = new QPushButton(frame_10);
        btnFilter_4->setObjectName("btnFilter_4");
        btnFilter_4->setStyleSheet(QString::fromUtf8("background-color:#a55eea;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:14px;"));

        searchLayout_4->addWidget(btnFilter_4);

        btnExporter_4 = new QPushButton(frame_10);
        btnExporter_4->setObjectName("btnExporter_4");
        btnExporter_4->setStyleSheet(QString::fromUtf8("background-color:#a55eea;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:14px;"));

        searchLayout_4->addWidget(btnExporter_4);


        verticalLayout_4->addLayout(searchLayout_4);

        headerLayout_8 = new QHBoxLayout();
        headerLayout_8->setObjectName("headerLayout_8");
        tableClients_2 = new QTableWidget(frame_10);
        if (tableClients_2->columnCount() < 7)
            tableClients_2->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem79 = new QTableWidgetItem();
        tableClients_2->setHorizontalHeaderItem(0, __qtablewidgetitem79);
        QTableWidgetItem *__qtablewidgetitem80 = new QTableWidgetItem();
        tableClients_2->setHorizontalHeaderItem(1, __qtablewidgetitem80);
        QTableWidgetItem *__qtablewidgetitem81 = new QTableWidgetItem();
        tableClients_2->setHorizontalHeaderItem(2, __qtablewidgetitem81);
        QTableWidgetItem *__qtablewidgetitem82 = new QTableWidgetItem();
        tableClients_2->setHorizontalHeaderItem(3, __qtablewidgetitem82);
        QTableWidgetItem *__qtablewidgetitem83 = new QTableWidgetItem();
        tableClients_2->setHorizontalHeaderItem(4, __qtablewidgetitem83);
        QTableWidgetItem *__qtablewidgetitem84 = new QTableWidgetItem();
        tableClients_2->setHorizontalHeaderItem(5, __qtablewidgetitem84);
        QTableWidgetItem *__qtablewidgetitem85 = new QTableWidgetItem();
        tableClients_2->setHorizontalHeaderItem(6, __qtablewidgetitem85);
        if (tableClients_2->rowCount() < 8)
            tableClients_2->setRowCount(8);
        QTableWidgetItem *__qtablewidgetitem86 = new QTableWidgetItem();
        tableClients_2->setItem(0, 0, __qtablewidgetitem86);
        QTableWidgetItem *__qtablewidgetitem87 = new QTableWidgetItem();
        tableClients_2->setItem(0, 1, __qtablewidgetitem87);
        QTableWidgetItem *__qtablewidgetitem88 = new QTableWidgetItem();
        tableClients_2->setItem(0, 2, __qtablewidgetitem88);
        QTableWidgetItem *__qtablewidgetitem89 = new QTableWidgetItem();
        __qtablewidgetitem89->setCheckState(Qt::Checked);
        tableClients_2->setItem(0, 3, __qtablewidgetitem89);
        QTableWidgetItem *__qtablewidgetitem90 = new QTableWidgetItem();
        tableClients_2->setItem(0, 4, __qtablewidgetitem90);
        QTableWidgetItem *__qtablewidgetitem91 = new QTableWidgetItem();
        tableClients_2->setItem(0, 5, __qtablewidgetitem91);
        QTableWidgetItem *__qtablewidgetitem92 = new QTableWidgetItem();
        tableClients_2->setItem(0, 6, __qtablewidgetitem92);
        QTableWidgetItem *__qtablewidgetitem93 = new QTableWidgetItem();
        tableClients_2->setItem(1, 0, __qtablewidgetitem93);
        QTableWidgetItem *__qtablewidgetitem94 = new QTableWidgetItem();
        tableClients_2->setItem(1, 1, __qtablewidgetitem94);
        QTableWidgetItem *__qtablewidgetitem95 = new QTableWidgetItem();
        tableClients_2->setItem(1, 2, __qtablewidgetitem95);
        QTableWidgetItem *__qtablewidgetitem96 = new QTableWidgetItem();
        __qtablewidgetitem96->setCheckState(Qt::Checked);
        tableClients_2->setItem(1, 3, __qtablewidgetitem96);
        QTableWidgetItem *__qtablewidgetitem97 = new QTableWidgetItem();
        tableClients_2->setItem(1, 4, __qtablewidgetitem97);
        QTableWidgetItem *__qtablewidgetitem98 = new QTableWidgetItem();
        tableClients_2->setItem(1, 5, __qtablewidgetitem98);
        QTableWidgetItem *__qtablewidgetitem99 = new QTableWidgetItem();
        tableClients_2->setItem(1, 6, __qtablewidgetitem99);
        QTableWidgetItem *__qtablewidgetitem100 = new QTableWidgetItem();
        tableClients_2->setItem(2, 0, __qtablewidgetitem100);
        QTableWidgetItem *__qtablewidgetitem101 = new QTableWidgetItem();
        tableClients_2->setItem(2, 1, __qtablewidgetitem101);
        QTableWidgetItem *__qtablewidgetitem102 = new QTableWidgetItem();
        tableClients_2->setItem(2, 2, __qtablewidgetitem102);
        QTableWidgetItem *__qtablewidgetitem103 = new QTableWidgetItem();
        __qtablewidgetitem103->setCheckState(Qt::Checked);
        tableClients_2->setItem(2, 3, __qtablewidgetitem103);
        QTableWidgetItem *__qtablewidgetitem104 = new QTableWidgetItem();
        tableClients_2->setItem(2, 4, __qtablewidgetitem104);
        QTableWidgetItem *__qtablewidgetitem105 = new QTableWidgetItem();
        tableClients_2->setItem(2, 5, __qtablewidgetitem105);
        QTableWidgetItem *__qtablewidgetitem106 = new QTableWidgetItem();
        tableClients_2->setItem(2, 6, __qtablewidgetitem106);
        tableClients_2->setObjectName("tableClients_2");
        tableClients_2->setStyleSheet(QString::fromUtf8("/*QHeaderView::section { background-color:#2d224c;color:white;font-weight:bold; } QTableWidget { background-color:white; }*/\n"
"QTableWidget {\n"
"    background-color: white;\n"
"	color: rgb(0, 0, 0);\n"
"    border-radius: 10px;\n"
"    gridline-color: #dfe6e9;\n"
"}\n"
"QHeaderView::section {\n"
"    background-color: #2d224c;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    padding: 8px;\n"
"    border: none;\n"
"}\n"
"QTableWidget::item {\n"
"    padding: 8px;\n"
"    border-bottom: 1px solid #dfe6e9;\n"
"}\n"
"QTableWidget::item:selected {\n"
"    background-color: #a29bfe;\n"
"    color: white;\n"
"}\n"
"image: url(:/new/prefix1/4298bb3a-cb0a-48b6-8f36-19903f2c73d8.png);"));

        headerLayout_8->addWidget(tableClients_2);


        verticalLayout_4->addLayout(headerLayout_8);

        actionButtonsLayout_4 = new QHBoxLayout();
        actionButtonsLayout_4->setObjectName("actionButtonsLayout_4");

        verticalLayout_4->addLayout(actionButtonsLayout_4);


        horizontalLayout_4->addLayout(verticalLayout_4);

        btnListeClients_6 = new QPushButton(page_11);
        btnListeClients_6->setObjectName("btnListeClients_6");
        btnListeClients_6->setGeometry(QRect(290, 10, 341, 41));
        btnListeClients_6->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        btnAjouterClient_6 = new QPushButton(page_11);
        btnAjouterClient_6->setObjectName("btnAjouterClient_6");
        btnAjouterClient_6->setGeometry(QRect(650, 10, 331, 41));
        btnAjouterClient_6->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        label_28 = new QLabel(page_11);
        label_28->setObjectName("label_28");
        label_28->setGeometry(QRect(1150, 20, 211, 31));
        label_28->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 0, 127);\n"
"border-color: rgb(0, 0, 255);"));
        label_28->setAlignment(Qt::AlignmentFlag::AlignCenter);
        frame_16 = new QFrame(page_11);
        frame_16->setObjectName("frame_16");
        frame_16->setGeometry(QRect(1150, 50, 211, 711));
        frame_16->setStyleSheet(QString::fromUtf8("background-color: rgb(186, 186, 186);"));
        frame_16->setFrameShape(QFrame::Shape::StyledPanel);
        frame_16->setFrameShadow(QFrame::Shadow::Raised);
        stackedWidget_5->addWidget(page_11);
        page_12 = new QWidget();
        page_12->setObjectName("page_12");
        stackedWidget_5->addWidget(page_12);
        page_13 = new QWidget();
        page_13->setObjectName("page_13");
        frameFicheClient_4 = new QFrame(page_13);
        frameFicheClient_4->setObjectName("frameFicheClient_4");
        frameFicheClient_4->setGeometry(QRect(250, 60, 1081, 631));
        frameFicheClient_4->setStyleSheet(QString::fromUtf8("border:2px solid #a55eea; border-radius:20px; background-color:#f5f6fa;\n"
"border-color: rgb(0, 0, 127);"));
        lblFicheClient_4 = new QLabel(frameFicheClient_4);
        lblFicheClient_4->setObjectName("lblFicheClient_4");
        lblFicheClient_4->setGeometry(QRect(280, 30, 481, 68));
        lblFicheClient_4->setFont(font1);
        lblFicheClient_4->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 127);"));
        lblFicheClient_4->setFrameShape(QFrame::Shape::StyledPanel);
        lblFicheClient_4->setFrameShadow(QFrame::Shadow::Raised);
        lblid_4 = new QLabel(frameFicheClient_4);
        lblid_4->setObjectName("lblid_4");
        lblid_4->setGeometry(QRect(60, 160, 91, 20));
        lblid_4->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lblnom_5 = new QLabel(frameFicheClient_4);
        lblnom_5->setObjectName("lblnom_5");
        lblnom_5->setGeometry(QRect(60, 210, 121, 20));
        lblnom_5->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lblprenom_4 = new QLabel(frameFicheClient_4);
        lblprenom_4->setObjectName("lblprenom_4");
        lblprenom_4->setGeometry(QRect(60, 450, 91, 20));
        lblprenom_4->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lbltel_4 = new QLabel(frameFicheClient_4);
        lbltel_4->setObjectName("lbltel_4");
        lbltel_4->setGeometry(QRect(60, 270, 121, 20));
        lbltel_4->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lblbirth_4 = new QLabel(frameFicheClient_4);
        lblbirth_4->setObjectName("lblbirth_4");
        lblbirth_4->setGeometry(QRect(60, 370, 91, 21));
        lblbirth_4->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        layoutWidget_4 = new QWidget(frameFicheClient_4);
        layoutWidget_4->setObjectName("layoutWidget_4");
        layoutWidget_4->setGeometry(QRect(790, 560, 240, 42));
        ajouterActionLayout_4 = new QHBoxLayout(layoutWidget_4);
        ajouterActionLayout_4->setObjectName("ajouterActionLayout_4");
        ajouterActionLayout_4->setContentsMargins(0, 0, 0, 0);
        btnConfirmer_4 = new QPushButton(layoutWidget_4);
        btnConfirmer_4->setObjectName("btnConfirmer_4");

        ajouterActionLayout_4->addWidget(btnConfirmer_4);

        btnAnnuler_4 = new QPushButton(layoutWidget_4);
        btnAnnuler_4->setObjectName("btnAnnuler_4");

        ajouterActionLayout_4->addWidget(btnAnnuler_4);

        lineEditNom_5 = new QLineEdit(frameFicheClient_4);
        lineEditNom_5->setObjectName("lineEditNom_5");
        lineEditNom_5->setGeometry(QRect(230, 210, 251, 26));
        lineEditNom_5->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditPhone_4 = new QLineEdit(frameFicheClient_4);
        lineEditPhone_4->setObjectName("lineEditPhone_4");
        lineEditPhone_4->setGeometry(QRect(230, 260, 251, 26));
        lineEditPhone_4->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditDateNaissance_5 = new QLineEdit(frameFicheClient_4);
        lineEditDateNaissance_5->setObjectName("lineEditDateNaissance_5");
        lineEditDateNaissance_5->setGeometry(QRect(230, 370, 251, 26));
        lineEditDateNaissance_5->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditID_4 = new QLineEdit(frameFicheClient_4);
        lineEditID_4->setObjectName("lineEditID_4");
        lineEditID_4->setGeometry(QRect(230, 160, 251, 26));
        lineEditID_4->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        comboCategorie = new QComboBox(frameFicheClient_4);
        comboCategorie->addItem(QString());
        comboCategorie->addItem(QString());
        comboCategorie->addItem(QString());
        comboCategorie->addItem(QString());
        comboCategorie->setObjectName("comboCategorie");
        comboCategorie->setGeometry(QRect(220, 440, 251, 31));
        lineEditPhone_5 = new QLineEdit(frameFicheClient_4);
        lineEditPhone_5->setObjectName("lineEditPhone_5");
        lineEditPhone_5->setGeometry(QRect(230, 320, 251, 26));
        lineEditPhone_5->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lbltel_5 = new QLabel(frameFicheClient_4);
        lbltel_5->setObjectName("lbltel_5");
        lbltel_5->setGeometry(QRect(60, 320, 121, 20));
        lbltel_5->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        btnAjouterClient_7 = new QPushButton(page_13);
        btnAjouterClient_7->setObjectName("btnAjouterClient_7");
        btnAjouterClient_7->setGeometry(QRect(650, 10, 331, 41));
        btnAjouterClient_7->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        btnListeClients_7 = new QPushButton(page_13);
        btnListeClients_7->setObjectName("btnListeClients_7");
        btnListeClients_7->setGeometry(QRect(290, 10, 341, 41));
        btnListeClients_7->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        stackedWidget_5->addWidget(page_13);
        stackedWidget->addWidget(fournisseur);
        produits = new QWidget();
        produits->setObjectName("produits");
        stackedWidget_6 = new QStackedWidget(produits);
        stackedWidget_6->setObjectName("stackedWidget_6");
        stackedWidget_6->setGeometry(QRect(0, 0, 1481, 811));
        stackedWidget_6->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        page_10 = new QWidget();
        page_10->setObjectName("page_10");
        frame_12 = new QFrame(page_10);
        frame_12->setObjectName("frame_12");
        frame_12->setGeometry(QRect(210, 120, 961, 691));
        frame_12->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        frame_12->setFrameShape(QFrame::Shape::StyledPanel);
        frame_12->setFrameShadow(QFrame::Shadow::Raised);
        horizontalLayout_5 = new QHBoxLayout(frame_12);
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName("verticalLayout_5");
        headerLayout_9 = new QHBoxLayout();
        headerLayout_9->setObjectName("headerLayout_9");

        verticalLayout_5->addLayout(headerLayout_9);

        lblListeClients_5 = new QLabel(frame_12);
        lblListeClients_5->setObjectName("lblListeClients_5");
        lblListeClients_5->setFont(font);
        lblListeClients_5->setStyleSheet(QString::fromUtf8("color:#2d224c;font-weight:bold;margin:16px 0 8px 0;\n"
"background-color: rgb(255, 255, 255);"));

        verticalLayout_5->addWidget(lblListeClients_5);

        searchLayout_5 = new QHBoxLayout();
        searchLayout_5->setObjectName("searchLayout_5");
        frame_13 = new QFrame(frame_12);
        frame_13->setObjectName("frame_13");
        frame_13->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 124);; border-radius:20px;"));
        frame_13->setFrameShape(QFrame::Shape::StyledPanel);
        frame_13->setFrameShadow(QFrame::Shadow::Raised);
        toolButton_27 = new QToolButton(frame_13);
        toolButton_27->setObjectName("toolButton_27");
        toolButton_27->setGeometry(QRect(20, 240, 141, 41));
        toolButton_27->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_28 = new QToolButton(frame_13);
        toolButton_28->setObjectName("toolButton_28");
        toolButton_28->setGeometry(QRect(20, 300, 141, 41));
        toolButton_28->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_29 = new QToolButton(frame_13);
        toolButton_29->setObjectName("toolButton_29");
        toolButton_29->setGeometry(QRect(20, 360, 141, 41));
        toolButton_29->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_30 = new QToolButton(frame_13);
        toolButton_30->setObjectName("toolButton_30");
        toolButton_30->setGeometry(QRect(20, 420, 141, 41));
        toolButton_30->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }"));
        toolButton_31 = new QToolButton(frame_13);
        toolButton_31->setObjectName("toolButton_31");
        toolButton_31->setGeometry(QRect(20, 180, 141, 41));
        toolButton_31->setStyleSheet(QString::fromUtf8("QToolButton { border: none; border-radius: 20px; color: white; padding: 10px; background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #9B59B6, stop:1 #BDC3C7); } QToolButton:hover { background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #BDC3C7, stop:1 #F8C8DC); }\n"
""));

        searchLayout_5->addWidget(frame_13);

        searchLineEdit_5 = new QLineEdit(frame_12);
        searchLineEdit_5->setObjectName("searchLineEdit_5");
        searchLineEdit_5->setStyleSheet(QString::fromUtf8("background-color:#f5f6fa;border-radius:10px;padding:8px 16px;font-size:14px;color :black;"));

        searchLayout_5->addWidget(searchLineEdit_5);

        btnRechercher_5 = new QPushButton(frame_12);
        btnRechercher_5->setObjectName("btnRechercher_5");

        searchLayout_5->addWidget(btnRechercher_5);

        comboProfession_5 = new QComboBox(frame_12);
        comboProfession_5->addItem(QString());
        comboProfession_5->addItem(QString());
        comboProfession_5->addItem(QString());
        comboProfession_5->addItem(QString());
        comboProfession_5->addItem(QString());
        comboProfession_5->addItem(QString());
        comboProfession_5->addItem(QString());
        comboProfession_5->setObjectName("comboProfession_5");
        comboProfession_5->setAcceptDrops(false);
        comboProfession_5->setStyleSheet(QString::fromUtf8("background-color:#f5f6fa;border-radius:10px;padding:8px 16px;font-size:14px;color :black; "));
        comboProfession_5->setEditable(false);

        searchLayout_5->addWidget(comboProfession_5);

        btnFilter_5 = new QPushButton(frame_12);
        btnFilter_5->setObjectName("btnFilter_5");
        btnFilter_5->setStyleSheet(QString::fromUtf8("background-color:#a55eea;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:14px;"));

        searchLayout_5->addWidget(btnFilter_5);

        btnExporter_5 = new QPushButton(frame_12);
        btnExporter_5->setObjectName("btnExporter_5");
        btnExporter_5->setStyleSheet(QString::fromUtf8("background-color:#a55eea;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:14px;"));

        searchLayout_5->addWidget(btnExporter_5);


        verticalLayout_5->addLayout(searchLayout_5);

        headerLayout_10 = new QHBoxLayout();
        headerLayout_10->setObjectName("headerLayout_10");
        tablePersonnel_3 = new QTableWidget(frame_12);
        if (tablePersonnel_3->columnCount() < 9)
            tablePersonnel_3->setColumnCount(9);
        QTableWidgetItem *__qtablewidgetitem107 = new QTableWidgetItem();
        tablePersonnel_3->setHorizontalHeaderItem(0, __qtablewidgetitem107);
        QTableWidgetItem *__qtablewidgetitem108 = new QTableWidgetItem();
        tablePersonnel_3->setHorizontalHeaderItem(1, __qtablewidgetitem108);
        QTableWidgetItem *__qtablewidgetitem109 = new QTableWidgetItem();
        tablePersonnel_3->setHorizontalHeaderItem(2, __qtablewidgetitem109);
        QTableWidgetItem *__qtablewidgetitem110 = new QTableWidgetItem();
        tablePersonnel_3->setHorizontalHeaderItem(3, __qtablewidgetitem110);
        QTableWidgetItem *__qtablewidgetitem111 = new QTableWidgetItem();
        tablePersonnel_3->setHorizontalHeaderItem(4, __qtablewidgetitem111);
        QTableWidgetItem *__qtablewidgetitem112 = new QTableWidgetItem();
        tablePersonnel_3->setHorizontalHeaderItem(5, __qtablewidgetitem112);
        QTableWidgetItem *__qtablewidgetitem113 = new QTableWidgetItem();
        tablePersonnel_3->setHorizontalHeaderItem(6, __qtablewidgetitem113);
        QTableWidgetItem *__qtablewidgetitem114 = new QTableWidgetItem();
        tablePersonnel_3->setHorizontalHeaderItem(7, __qtablewidgetitem114);
        QTableWidgetItem *__qtablewidgetitem115 = new QTableWidgetItem();
        tablePersonnel_3->setHorizontalHeaderItem(8, __qtablewidgetitem115);
        if (tablePersonnel_3->rowCount() < 8)
            tablePersonnel_3->setRowCount(8);
        QTableWidgetItem *__qtablewidgetitem116 = new QTableWidgetItem();
        tablePersonnel_3->setItem(0, 0, __qtablewidgetitem116);
        QTableWidgetItem *__qtablewidgetitem117 = new QTableWidgetItem();
        tablePersonnel_3->setItem(0, 1, __qtablewidgetitem117);
        QTableWidgetItem *__qtablewidgetitem118 = new QTableWidgetItem();
        tablePersonnel_3->setItem(0, 2, __qtablewidgetitem118);
        QTableWidgetItem *__qtablewidgetitem119 = new QTableWidgetItem();
        tablePersonnel_3->setItem(0, 3, __qtablewidgetitem119);
        QTableWidgetItem *__qtablewidgetitem120 = new QTableWidgetItem();
        tablePersonnel_3->setItem(0, 8, __qtablewidgetitem120);
        QTableWidgetItem *__qtablewidgetitem121 = new QTableWidgetItem();
        tablePersonnel_3->setItem(1, 0, __qtablewidgetitem121);
        QTableWidgetItem *__qtablewidgetitem122 = new QTableWidgetItem();
        tablePersonnel_3->setItem(1, 1, __qtablewidgetitem122);
        QTableWidgetItem *__qtablewidgetitem123 = new QTableWidgetItem();
        tablePersonnel_3->setItem(1, 2, __qtablewidgetitem123);
        QTableWidgetItem *__qtablewidgetitem124 = new QTableWidgetItem();
        tablePersonnel_3->setItem(1, 3, __qtablewidgetitem124);
        QTableWidgetItem *__qtablewidgetitem125 = new QTableWidgetItem();
        tablePersonnel_3->setItem(2, 0, __qtablewidgetitem125);
        QTableWidgetItem *__qtablewidgetitem126 = new QTableWidgetItem();
        tablePersonnel_3->setItem(2, 1, __qtablewidgetitem126);
        QTableWidgetItem *__qtablewidgetitem127 = new QTableWidgetItem();
        tablePersonnel_3->setItem(2, 2, __qtablewidgetitem127);
        QTableWidgetItem *__qtablewidgetitem128 = new QTableWidgetItem();
        tablePersonnel_3->setItem(2, 3, __qtablewidgetitem128);
        tablePersonnel_3->setObjectName("tablePersonnel_3");
        tablePersonnel_3->setStyleSheet(QString::fromUtf8("/* --- Style du conteneur principal de la table --- */\n"
"QTableWidget {\n"
"    background-color: white;\n"
"    color: rgb(0, 0, 0);\n"
"    border-radius: 10px;\n"
"    gridline-color: #dfe6e9;\n"
"    border: 1px solid #dfe6e9;\n"
"}\n"
"\n"
"/* --- Style de l'en-t\303\252te --- */\n"
"QHeaderView::section {\n"
"    background-color: #2d224c;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    padding: 8px;\n"
"    border: none;\n"
"}\n"
"\n"
"/* --- Style pour chaque cellule (SANS PADDING) --- */\n"
"QTableWidget::item {\n"
"    border-bottom: 1px solid #dfe6e9;\n"
"}\n"
"\n"
"/* --- Style pour les cellules s\303\251lectionn\303\251es --- */\n"
"QTableWidget::item:selected {\n"
"    background-color: #a29bfe;\n"
"    color: white;\n"
"}"));

        headerLayout_10->addWidget(tablePersonnel_3);


        verticalLayout_5->addLayout(headerLayout_10);

        actionButtonsLayout_5 = new QHBoxLayout();
        actionButtonsLayout_5->setObjectName("actionButtonsLayout_5");

        verticalLayout_5->addLayout(actionButtonsLayout_5);


        horizontalLayout_5->addLayout(verticalLayout_5);

        btnListePersonnel_5 = new QPushButton(page_10);
        btnListePersonnel_5->setObjectName("btnListePersonnel_5");
        btnListePersonnel_5->setGeometry(QRect(270, 60, 341, 41));
        btnListePersonnel_5->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        btnAjouterPersonnel_5 = new QPushButton(page_10);
        btnAjouterPersonnel_5->setObjectName("btnAjouterPersonnel_5");
        btnAjouterPersonnel_5->setGeometry(QRect(640, 60, 331, 41));
        btnAjouterPersonnel_5->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        label_32 = new QLabel(page_10);
        label_32->setObjectName("label_32");
        label_32->setGeometry(QRect(1190, 50, 211, 31));
        label_32->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 0, 127);\n"
"border-color: rgb(0, 0, 255);"));
        label_32->setAlignment(Qt::AlignmentFlag::AlignCenter);
        frame_18 = new QFrame(page_10);
        frame_18->setObjectName("frame_18");
        frame_18->setGeometry(QRect(1190, 80, 211, 711));
        frame_18->setStyleSheet(QString::fromUtf8("background-color: rgb(186, 186, 186);"));
        frame_18->setFrameShape(QFrame::Shape::StyledPanel);
        frame_18->setFrameShadow(QFrame::Shadow::Raised);
        label_33 = new QLabel(frame_18);
        label_33->setObjectName("label_33");
        label_33->setGeometry(QRect(10, -20, 191, 351));
        label_33->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/784a706a-f6af-4062-9180-299d6847a0c1.png")));
        label_33->setScaledContents(true);
        label_33->setWordWrap(false);
        label_33->setOpenExternalLinks(true);
        label_34 = new QLabel(frame_18);
        label_34->setObjectName("label_34");
        label_34->setGeometry(QRect(10, 340, 191, 351));
        label_34->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/456.png")));
        label_34->setScaledContents(true);
        label_34->setWordWrap(true);
        label_34->setOpenExternalLinks(true);
        stackedWidget_6->addWidget(page_10);
        page_14 = new QWidget();
        page_14->setObjectName("page_14");
        stackedWidget_6->addWidget(page_14);
        page_15 = new QWidget();
        page_15->setObjectName("page_15");
        page_16 = new QWidget(page_15);
        page_16->setObjectName("page_16");
        page_16->setGeometry(QRect(220, 70, 1361, 671));
        btnAjouterClient_8 = new QPushButton(page_16);
        btnAjouterClient_8->setObjectName("btnAjouterClient_8");
        btnAjouterClient_8->setGeometry(QRect(420, 0, 331, 41));
        btnAjouterClient_8->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        btnListeClients_8 = new QPushButton(page_16);
        btnListeClients_8->setObjectName("btnListeClients_8");
        btnListeClients_8->setGeometry(QRect(40, 0, 341, 41));
        btnListeClients_8->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #41375f;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border-radius: 15px;\n"
"    padding: 12px 24px;\n"
"    font-size: 15px;\n"
"    border: 2px solid #41375f;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5a4a82;\n"
"    border: 2px solid #7158a0;\n"
"}"));
        label_29 = new QLabel(page_16);
        label_29->setObjectName("label_29");
        label_29->setGeometry(QRect(1010, 0, 211, 31));
        label_29->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(255, 0, 0);\n"
"border-color: rgb(0, 0, 255);\n"
"font-size :20px;\n"
"border-top-right-radius: 20px;\n"
"border-top-left-radius: 20px;"));
        label_29->setAlignment(Qt::AlignmentFlag::AlignCenter);
        frame_17 = new QFrame(page_16);
        frame_17->setObjectName("frame_17");
        frame_17->setGeometry(QRect(1010, 30, 211, 631));
        frame_17->setStyleSheet(QString::fromUtf8("background-color: rgb(186, 186, 186);\n"
"border-bottom-right-radius: 25px;\n"
"border-bottom-left-radius: 25px;"));
        frame_17->setFrameShape(QFrame::Shape::StyledPanel);
        frame_17->setFrameShadow(QFrame::Shadow::Raised);
        label_18 = new QLabel(frame_17);
        label_18->setObjectName("label_18");
        label_18->setGeometry(QRect(10, 100, 191, 201));
        label_18->setAutoFillBackground(false);
        label_18->setPixmap(QPixmap(QString::fromUtf8(":/new/prefix1/fd6699_5ad46a373a2e4385bddfb0c531358041~mv2.png")));
        label_18->setScaledContents(true);
        tableWidget = new QTableWidget(frame_17);
        if (tableWidget->columnCount() < 1)
            tableWidget->setColumnCount(1);
        QTableWidgetItem *__qtablewidgetitem129 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem129);
        if (tableWidget->rowCount() < 5)
            tableWidget->setRowCount(5);
        QTableWidgetItem *__qtablewidgetitem130 = new QTableWidgetItem();
        tableWidget->setItem(0, 0, __qtablewidgetitem130);
        QTableWidgetItem *__qtablewidgetitem131 = new QTableWidgetItem();
        tableWidget->setItem(1, 0, __qtablewidgetitem131);
        QTableWidgetItem *__qtablewidgetitem132 = new QTableWidgetItem();
        tableWidget->setItem(2, 0, __qtablewidgetitem132);
        QTableWidgetItem *__qtablewidgetitem133 = new QTableWidgetItem();
        tableWidget->setItem(3, 0, __qtablewidgetitem133);
        QTableWidgetItem *__qtablewidgetitem134 = new QTableWidgetItem();
        tableWidget->setItem(4, 0, __qtablewidgetitem134);
        tableWidget->setObjectName("tableWidget");
        tableWidget->setGeometry(QRect(40, 340, 131, 181));
        tableWidget->setStyleSheet(QString::fromUtf8("/* --- Style du conteneur principal de la table --- */\n"
"QTableWidget {\n"
"    background-color: white;\n"
"    color: rgb(0, 0, 0);\n"
"    border-radius: 10px;\n"
"    gridline-color: #dfe6e9;\n"
"    border: 1px solid #dfe6e9;\n"
"}\n"
"\n"
"/* --- Style de l'en-t\303\252te --- */\n"
"QHeaderView::section {\n"
"    background-color: #2d224c;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    padding: 8px;\n"
"    border: none;\n"
"}\n"
"\n"
"/* --- Style pour chaque cellule (SANS PADDING) --- */\n"
"QTableWidget::item {\n"
"    border-bottom: 1px solid #dfe6e9;\n"
"}\n"
"\n"
"/* --- Style pour les cellules s\303\251lectionn\303\251es --- */\n"
"QTableWidget::item:selected {\n"
"    background-color: #a29bfe;\n"
"    color: white;\n"
"}"));
        frameFicheClient_5 = new QFrame(page_16);
        frameFicheClient_5->setObjectName("frameFicheClient_5");
        frameFicheClient_5->setGeometry(QRect(20, 90, 951, 541));
        frameFicheClient_5->setStyleSheet(QString::fromUtf8("border:2px solid #a55eea; border-radius:20px; background-color:#f5f6fa;\n"
"border-color: rgb(0, 0, 127);"));
        lblFicheClient_5 = new QLabel(frameFicheClient_5);
        lblFicheClient_5->setObjectName("lblFicheClient_5");
        lblFicheClient_5->setGeometry(QRect(370, 10, 211, 68));
        lblFicheClient_5->setFont(font1);
        lblFicheClient_5->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 127);"));
        lblFicheClient_5->setFrameShape(QFrame::Shape::StyledPanel);
        lblFicheClient_5->setFrameShadow(QFrame::Shadow::Raised);
        label_5 = new QLabel(frameFicheClient_5);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(100, 90, 91, 20));
        label_5->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        label_6 = new QLabel(frameFicheClient_5);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(100, 130, 91, 20));
        label_6->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        label_7 = new QLabel(frameFicheClient_5);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(100, 170, 91, 20));
        label_7->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        label_24 = new QLabel(frameFicheClient_5);
        label_24->setObjectName("label_24");
        label_24->setGeometry(QRect(100, 210, 91, 20));
        label_24->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        label_25 = new QLabel(frameFicheClient_5);
        label_25->setObjectName("label_25");
        label_25->setGeometry(QRect(100, 290, 91, 20));
        label_25->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        label_30 = new QLabel(frameFicheClient_5);
        label_30->setObjectName("label_30");
        label_30->setGeometry(QRect(100, 250, 91, 21));
        label_30->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        layoutWidget_5 = new QWidget(frameFicheClient_5);
        layoutWidget_5->setObjectName("layoutWidget_5");
        layoutWidget_5->setGeometry(QRect(670, 470, 240, 45));
        ajouterActionLayout_5 = new QHBoxLayout(layoutWidget_5);
        ajouterActionLayout_5->setObjectName("ajouterActionLayout_5");
        ajouterActionLayout_5->setContentsMargins(0, 0, 0, 0);
        btnAnnuler_5 = new QPushButton(layoutWidget_5);
        btnAnnuler_5->setObjectName("btnAnnuler_5");
        btnAnnuler_5->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    border-radius: 20px;\n"
"    color: white;\n"
"    padding: 12px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #6c5ce7, stop:1 #a29bfe);\n"
"    font-weight: bold;\n"
"    font-size: 14px;\n"
"}\n"
"QPushButton:hover {\n"
"font-size: 20px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #a29bfe, stop:1 #fd79a8);\n"
"}"));

        ajouterActionLayout_5->addWidget(btnAnnuler_5);

        btnConfirmer_5 = new QPushButton(layoutWidget_5);
        btnConfirmer_5->setObjectName("btnConfirmer_5");
        btnConfirmer_5->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    border-radius: 20px;\n"
"    color: white;\n"
"    padding: 12px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #6c5ce7, stop:1 #a29bfe);\n"
"    font-weight: bold;\n"
"    font-size: 14px;\n"
"}\n"
"QPushButton:hover {\n"
"font-size: 20px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 #a29bfe, stop:1 #fd79a8);\n"
"}"));

        ajouterActionLayout_5->addWidget(btnConfirmer_5);

        lineEditNom_6 = new QLineEdit(frameFicheClient_5);
        lineEditNom_6->setObjectName("lineEditNom_6");
        lineEditNom_6->setGeometry(QRect(220, 130, 251, 26));
        lineEditNom_6->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditDateNaissance_6 = new QLineEdit(frameFicheClient_5);
        lineEditDateNaissance_6->setObjectName("lineEditDateNaissance_6");
        lineEditDateNaissance_6->setGeometry(QRect(220, 250, 251, 26));
        lineEditDateNaissance_6->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditID_5 = new QLineEdit(frameFicheClient_5);
        lineEditID_5->setObjectName("lineEditID_5");
        lineEditID_5->setGeometry(QRect(220, 90, 251, 26));
        lineEditID_5->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        lineEditPrenom_4 = new QLineEdit(frameFicheClient_5);
        lineEditPrenom_4->setObjectName("lineEditPrenom_4");
        lineEditPrenom_4->setGeometry(QRect(220, 170, 251, 26));
        lineEditPrenom_4->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_31 = new QLabel(frameFicheClient_5);
        label_31->setObjectName("label_31");
        label_31->setGeometry(QRect(100, 330, 91, 20));
        label_31->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        label_35 = new QLabel(frameFicheClient_5);
        label_35->setObjectName("label_35");
        label_35->setGeometry(QRect(100, 370, 91, 20));
        label_35->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        lineEditDateNaissance_7 = new QLineEdit(frameFicheClient_5);
        lineEditDateNaissance_7->setObjectName("lineEditDateNaissance_7");
        lineEditDateNaissance_7->setGeometry(QRect(220, 290, 251, 26));
        lineEditDateNaissance_7->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        spinBox = new QSpinBox(frameFicheClient_5);
        spinBox->setObjectName("spinBox");
        spinBox->setGeometry(QRect(220, 370, 141, 25));
        spinBox->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        spinBox->setStepType(QAbstractSpinBox::StepType::AdaptiveDecimalStepType);
        spinBox_2 = new QSpinBox(frameFicheClient_5);
        spinBox_2->setObjectName("spinBox_2");
        spinBox_2->setGeometry(QRect(220, 330, 141, 25));
        spinBox_2->setStyleSheet(QString::fromUtf8("color :black;"));
        calendarWidget = new QCalendarWidget(frameFicheClient_5);
        calendarWidget->setObjectName("calendarWidget");
        calendarWidget->setGeometry(QRect(550, 200, 256, 163));
        calendarWidget->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_36 = new QLabel(frameFicheClient_5);
        label_36->setObjectName("label_36");
        label_36->setGeometry(QRect(550, 160, 91, 20));
        label_36->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        dateEdit = new QDateEdit(frameFicheClient_5);
        dateEdit->setObjectName("dateEdit");
        dateEdit->setGeometry(QRect(660, 160, 110, 25));
        dateEdit->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        line = new QFrame(frameFicheClient_5);
        line->setObjectName("line");
        line->setGeometry(QRect(500, 80, 20, 371));
        line->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        line->setFrameShape(QFrame::Shape::VLine);
        line->setFrameShadow(QFrame::Shadow::Sunken);
        comboProfession_6 = new QComboBox(frameFicheClient_5);
        comboProfession_6->addItem(QString());
        comboProfession_6->addItem(QString());
        comboProfession_6->addItem(QString());
        comboProfession_6->addItem(QString());
        comboProfession_6->addItem(QString());
        comboProfession_6->addItem(QString());
        comboProfession_6->setObjectName("comboProfession_6");
        comboProfession_6->setGeometry(QRect(220, 200, 91, 41));
        comboProfession_6->setStyleSheet(QString::fromUtf8("background-color:#41375f;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:15px;"));
        comboProfession_6->setEditable(false);
        label_37 = new QLabel(frameFicheClient_5);
        label_37->setObjectName("label_37");
        label_37->setGeometry(QRect(100, 410, 91, 20));
        label_37->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        comboProfession_7 = new QComboBox(frameFicheClient_5);
        comboProfession_7->addItem(QString());
        comboProfession_7->addItem(QString());
        comboProfession_7->addItem(QString());
        comboProfession_7->addItem(QString());
        comboProfession_7->setObjectName("comboProfession_7");
        comboProfession_7->setGeometry(QRect(220, 400, 121, 41));
        comboProfession_7->setStyleSheet(QString::fromUtf8("background-color:#41375f;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:15px;"));
        comboProfession_7->setEditable(false);
        comboProfession_8 = new QComboBox(frameFicheClient_5);
        comboProfession_8->addItem(QString());
        comboProfession_8->addItem(QString());
        comboProfession_8->addItem(QString());
        comboProfession_8->addItem(QString());
        comboProfession_8->setObjectName("comboProfession_8");
        comboProfession_8->setGeometry(QRect(670, 100, 121, 41));
        comboProfession_8->setStyleSheet(QString::fromUtf8("background-color:#41375f;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:15px;"));
        comboProfession_8->setEditable(false);
        label_38 = new QLabel(frameFicheClient_5);
        label_38->setObjectName("label_38");
        label_38->setGeometry(QRect(550, 110, 91, 20));
        label_38->setStyleSheet(QString::fromUtf8("background-color: rgb(48, 71, 120);"));
        stackedWidget_6->addWidget(page_15);
        stackedWidget->addWidget(produits);
        MainWindow->setCentralWidget(centralwidget);
        stackedWidget->raise();
        frame_6->raise();
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1499, 29));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(0);
        stackedWidget_3->setCurrentIndex(2);
        stackedWidget_2->setCurrentIndex(2);
        stackedWidget_4->setCurrentIndex(2);
        stackedWidget_5->setCurrentIndex(2);
        stackedWidget_6->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        toolButton_fourn1->setText(QCoreApplication::translate("MainWindow", "      Fournisseurs", nullptr));
        toolButton_prod1->setText(QCoreApplication::translate("MainWindow", "     Produits", nullptr));
        toolButton_person1->setText(QCoreApplication::translate("MainWindow", "      Personnel", nullptr));
        toolButton_loc1->setText(QCoreApplication::translate("MainWindow", "Locaux", nullptr));
        toolButton_client1->setText(QCoreApplication::translate("MainWindow", " Clients", nullptr));
        label_4->setText(QString());
        label_11->setText(QString());
        label_12->setText(QString());
        label_13->setText(QString());
        label_14->setText(QString());
        label_15->setText(QString());
        lblListeClients->setText(QCoreApplication::translate("MainWindow", "Liste du Personnel", nullptr));
        toolButton_6->setText(QCoreApplication::translate("MainWindow", "Fournisseurs", nullptr));
        toolButton_7->setText(QCoreApplication::translate("MainWindow", "Produis", nullptr));
        toolButton_8->setText(QCoreApplication::translate("MainWindow", "Personnels", nullptr));
        toolButton_9->setText(QCoreApplication::translate("MainWindow", "Locaux", nullptr));
        toolButton_10->setText(QCoreApplication::translate("MainWindow", "Client", nullptr));
        searchLineEdit->setPlaceholderText(QCoreApplication::translate("MainWindow", "Rechercher par ID ou Nom", nullptr));
        btnRechercher->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#a55eea;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:14px;", nullptr));
        btnRechercher->setText(QCoreApplication::translate("MainWindow", "Rechercher", nullptr));
        comboProfession->setItemText(0, QCoreApplication::translate("MainWindow", "R\303\264les", nullptr));
        comboProfession->setItemText(1, QCoreApplication::translate("MainWindow", "Responsable", nullptr));
        comboProfession->setItemText(2, QCoreApplication::translate("MainWindow", "Vendeur", nullptr));
        comboProfession->setItemText(3, QCoreApplication::translate("MainWindow", "Manager", nullptr));
        comboProfession->setItemText(4, QCoreApplication::translate("MainWindow", "Opticien", nullptr));

        comboProfession->setCurrentText(QCoreApplication::translate("MainWindow", "R\303\264les", nullptr));
        btnFilter->setText(QCoreApplication::translate("MainWindow", "Filter", nullptr));
        btnExporter->setText(QCoreApplication::translate("MainWindow", "Exporter ", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tablePersonnel->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tablePersonnel->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MainWindow", "Nom", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tablePersonnel->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("MainWindow", "Pr\303\251nom", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tablePersonnel->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("MainWindow", "Telephone", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = tablePersonnel->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("MainWindow", "Mail", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = tablePersonnel->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("MainWindow", "R\303\264le", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = tablePersonnel->horizontalHeaderItem(6);
        ___qtablewidgetitem6->setText(QCoreApplication::translate("MainWindow", "Statut", nullptr));
        QTableWidgetItem *___qtablewidgetitem7 = tablePersonnel->horizontalHeaderItem(7);
        ___qtablewidgetitem7->setText(QCoreApplication::translate("MainWindow", "Documents", nullptr));
        QTableWidgetItem *___qtablewidgetitem8 = tablePersonnel->horizontalHeaderItem(8);
        ___qtablewidgetitem8->setText(QCoreApplication::translate("MainWindow", "Permissions", nullptr));
        QTableWidgetItem *___qtablewidgetitem9 = tablePersonnel->horizontalHeaderItem(9);
        ___qtablewidgetitem9->setText(QCoreApplication::translate("MainWindow", "Actions", nullptr));

        const bool __sortingEnabled = tablePersonnel->isSortingEnabled();
        tablePersonnel->setSortingEnabled(false);
        tablePersonnel->setSortingEnabled(__sortingEnabled);

        btnListePersonnel_3->setText(QCoreApplication::translate("MainWindow", "Liste du Personnel", nullptr));
        btnAjouterPersonnel_3->setText(QCoreApplication::translate("MainWindow", "Ajouter Personnel", nullptr));
        label_16->setText(QCoreApplication::translate("MainWindow", "Statistiques", nullptr));
        lblFicheClient->setText(QCoreApplication::translate("MainWindow", "Fiche Personnel", nullptr));
        lblid->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        lblnom->setText(QCoreApplication::translate("MainWindow", "Nom", nullptr));
        lblprenom->setText(QCoreApplication::translate("MainWindow", "Pr\303\251nom", nullptr));
        lbltel->setText(QCoreApplication::translate("MainWindow", "Telephone", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "Sexe", nullptr));
        lblbirth->setText(QCoreApplication::translate("MainWindow", "R\303\264le", nullptr));
        btnConfirmer->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#2980b9;color:white;font-weight:bold;border-radius:15px;padding:8px 24px;font-size:15px;", nullptr));
        btnConfirmer->setText(QCoreApplication::translate("MainWindow", "Confirmer", nullptr));
        btnAnnuler->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#636e72;color:white;font-weight:bold;border-radius:15px;padding:8px 24px;font-size:15px;", nullptr));
        btnAnnuler->setText(QCoreApplication::translate("MainWindow", "Annuler", nullptr));
        lineEditNom->setText(QString());
        lineEditNom->setPlaceholderText(QCoreApplication::translate("MainWindow", "Nom", nullptr));
        lineEditPhone->setText(QString());
        lineEditPhone->setPlaceholderText(QCoreApplication::translate("MainWindow", "T\303\251l\303\251phone", nullptr));
        lineEditDateNaissance->setText(QString());
        lineEditDateNaissance->setPlaceholderText(QCoreApplication::translate("MainWindow", "R\303\264le", nullptr));
        lineEditID->setText(QString());
        lineEditID->setPlaceholderText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        lineEditPrenom->setText(QString());
        lineEditPrenom->setPlaceholderText(QCoreApplication::translate("MainWindow", "Pr\303\251nom", nullptr));
        comboSexe->setItemText(0, QCoreApplication::translate("MainWindow", "Homme", nullptr));
        comboSexe->setItemText(1, QCoreApplication::translate("MainWindow", "Femme", nullptr));

        comboSexe->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#41375f;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:15px;", nullptr));
        lblnom_2->setText(QCoreApplication::translate("MainWindow", "Mail", nullptr));
        lineEditNom_2->setText(QString());
        lineEditNom_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "Mail", nullptr));
        btnAjouterClient_2->setText(QCoreApplication::translate("MainWindow", "Ajouter Personnel", nullptr));
        btnListeClients_2->setText(QCoreApplication::translate("MainWindow", "Liste du Personnel", nullptr));
        lblListeClients_2->setText(QCoreApplication::translate("MainWindow", "Liste du locaux", nullptr));
        toolButton_11->setText(QCoreApplication::translate("MainWindow", "Fournisseurs", nullptr));
        toolButton_12->setText(QCoreApplication::translate("MainWindow", "Produis", nullptr));
        toolButton_13->setText(QCoreApplication::translate("MainWindow", "Personnels", nullptr));
        toolButton_14->setText(QCoreApplication::translate("MainWindow", "Locaux", nullptr));
        toolButton_15->setText(QCoreApplication::translate("MainWindow", "Client", nullptr));
        searchLineEdit_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "\360\237\224\216 Rechercher par ID ou Nom du local...", nullptr));
        btnRechercher_2->setText(QCoreApplication::translate("MainWindow", "Rechercher", nullptr));
        comboProfession_2->setItemText(0, QCoreApplication::translate("MainWindow", "ID", nullptr));
        comboProfession_2->setItemText(1, QCoreApplication::translate("MainWindow", "Nom", nullptr));
        comboProfession_2->setItemText(2, QCoreApplication::translate("MainWindow", "Superficie", nullptr));
        comboProfession_2->setItemText(3, QCoreApplication::translate("MainWindow", "Etat d'un local", nullptr));

        comboProfession_2->setCurrentText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        btnFilter_2->setText(QCoreApplication::translate("MainWindow", "Filter", nullptr));
        btnExporter_2->setText(QCoreApplication::translate("MainWindow", "Exporter ", nullptr));
        QTableWidgetItem *___qtablewidgetitem10 = tablePersonnel_2->horizontalHeaderItem(0);
        ___qtablewidgetitem10->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem11 = tablePersonnel_2->horizontalHeaderItem(1);
        ___qtablewidgetitem11->setText(QCoreApplication::translate("MainWindow", "Nom", nullptr));
        QTableWidgetItem *___qtablewidgetitem12 = tablePersonnel_2->horizontalHeaderItem(2);
        ___qtablewidgetitem12->setText(QCoreApplication::translate("MainWindow", "Telephone", nullptr));
        QTableWidgetItem *___qtablewidgetitem13 = tablePersonnel_2->horizontalHeaderItem(3);
        ___qtablewidgetitem13->setText(QCoreApplication::translate("MainWindow", "Adresse", nullptr));
        QTableWidgetItem *___qtablewidgetitem14 = tablePersonnel_2->horizontalHeaderItem(4);
        ___qtablewidgetitem14->setText(QCoreApplication::translate("MainWindow", "Superficie", nullptr));
        QTableWidgetItem *___qtablewidgetitem15 = tablePersonnel_2->horizontalHeaderItem(5);
        ___qtablewidgetitem15->setText(QCoreApplication::translate("MainWindow", "Chiffre d'affaires", nullptr));
        QTableWidgetItem *___qtablewidgetitem16 = tablePersonnel_2->horizontalHeaderItem(6);
        ___qtablewidgetitem16->setText(QCoreApplication::translate("MainWindow", "Etat d'un local", nullptr));
        QTableWidgetItem *___qtablewidgetitem17 = tablePersonnel_2->horizontalHeaderItem(7);
        ___qtablewidgetitem17->setText(QCoreApplication::translate("MainWindow", "Actions", nullptr));

        const bool __sortingEnabled1 = tablePersonnel_2->isSortingEnabled();
        tablePersonnel_2->setSortingEnabled(false);
        tablePersonnel_2->setSortingEnabled(__sortingEnabled1);

        btnListePersonnel_4->setText(QCoreApplication::translate("MainWindow", "Liste du locaux", nullptr));
        btnAjouterPersonnel_4->setText(QCoreApplication::translate("MainWindow", "Ajouter un local", nullptr));
        label_19->setText(QString());
        label_26->setText(QCoreApplication::translate("MainWindow", "Statistiques", nullptr));
        lblFicheClient_2->setText(QCoreApplication::translate("MainWindow", "Fiche d'un local", nullptr));
        lblid_2->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        lblnom_3->setText(QCoreApplication::translate("MainWindow", "Nom", nullptr));
        lblprenom_2->setText(QCoreApplication::translate("MainWindow", "Adresse", nullptr));
        lbltel_2->setText(QCoreApplication::translate("MainWindow", "Telephone", nullptr));
        lblbirth_2->setText(QCoreApplication::translate("MainWindow", "Superficie", nullptr));
        btnConfirmer_2->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#2980b9;color:white;font-weight:bold;border-radius:15px;padding:8px 24px;font-size:15px;", nullptr));
        btnConfirmer_2->setText(QCoreApplication::translate("MainWindow", "Confirmer", nullptr));
        btnAnnuler_2->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#636e72;color:white;font-weight:bold;border-radius:15px;padding:8px 24px;font-size:15px;", nullptr));
        btnAnnuler_2->setText(QCoreApplication::translate("MainWindow", "Annuler", nullptr));
        lineEditNom_3->setText(QString());
        lineEditNom_3->setPlaceholderText(QCoreApplication::translate("MainWindow", "Nom", nullptr));
        lineEditPhone_2->setText(QString());
        lineEditPhone_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "T\303\251l\303\251phone", nullptr));
        lineEditDateNaissance_2->setText(QString());
        lineEditDateNaissance_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "surface du local", nullptr));
        lineEditID_2->setText(QString());
        lineEditID_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        lineEditPrenom_2->setText(QString());
        lineEditPrenom_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "Adresse", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "Chiffre d'affaires", nullptr));
        lineEditDateNaissance_3->setText(QString());
        lineEditDateNaissance_3->setPlaceholderText(QCoreApplication::translate("MainWindow", "Performance commerciale", nullptr));
        label_27->setText(QCoreApplication::translate("MainWindow", "Etat du local", nullptr));
        checkOld->setText(QCoreApplication::translate("MainWindow", "Disponible", nullptr));
        checkNew->setText(QCoreApplication::translate("MainWindow", "Ouvert", nullptr));
        checkVIP->setText(QCoreApplication::translate("MainWindow", "Ferme", nullptr));
        label->setText(QString());
        btnAjouterClient_3->setText(QCoreApplication::translate("MainWindow", "Ajouter local", nullptr));
        btnListeClients_3->setText(QCoreApplication::translate("MainWindow", "Liste des Locaux", nullptr));
        lblListeClients_3->setText(QCoreApplication::translate("MainWindow", "Liste des Clients", nullptr));
        toolButton_17->setText(QCoreApplication::translate("MainWindow", "Fournisseurs", nullptr));
        toolButton_18->setText(QCoreApplication::translate("MainWindow", "Produis", nullptr));
        toolButton_19->setText(QCoreApplication::translate("MainWindow", "Personnels", nullptr));
        toolButton_20->setText(QCoreApplication::translate("MainWindow", "Locaux", nullptr));
        toolButton_21->setText(QCoreApplication::translate("MainWindow", "Client", nullptr));
        searchLineEdit_3->setPlaceholderText(QCoreApplication::translate("MainWindow", "Rechercher par ID ou Nom", nullptr));
        btnRechercher_3->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#a55eea;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:14px;", nullptr));
        btnRechercher_3->setText(QCoreApplication::translate("MainWindow", "Rechercher", nullptr));
        comboProfession_3->setItemText(0, QCoreApplication::translate("MainWindow", "Profession", nullptr));

        btnFilter_3->setText(QCoreApplication::translate("MainWindow", "Filter", nullptr));
        btnExporter_3->setText(QCoreApplication::translate("MainWindow", "Exporter ", nullptr));
        QTableWidgetItem *___qtablewidgetitem18 = tableClients->horizontalHeaderItem(0);
        ___qtablewidgetitem18->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem19 = tableClients->horizontalHeaderItem(1);
        ___qtablewidgetitem19->setText(QCoreApplication::translate("MainWindow", "Nom", nullptr));
        QTableWidgetItem *___qtablewidgetitem20 = tableClients->horizontalHeaderItem(2);
        ___qtablewidgetitem20->setText(QCoreApplication::translate("MainWindow", "Pr\303\251nom", nullptr));
        QTableWidgetItem *___qtablewidgetitem21 = tableClients->horizontalHeaderItem(3);
        ___qtablewidgetitem21->setText(QCoreApplication::translate("MainWindow", "\303\202ge", nullptr));
        QTableWidgetItem *___qtablewidgetitem22 = tableClients->horizontalHeaderItem(4);
        ___qtablewidgetitem22->setText(QCoreApplication::translate("MainWindow", "Statut de Fid\303\251lit\303\251", nullptr));
        QTableWidgetItem *___qtablewidgetitem23 = tableClients->horizontalHeaderItem(5);
        ___qtablewidgetitem23->setText(QCoreApplication::translate("MainWindow", "Numero de telephone", nullptr));
        QTableWidgetItem *___qtablewidgetitem24 = tableClients->horizontalHeaderItem(6);
        ___qtablewidgetitem24->setText(QCoreApplication::translate("MainWindow", "sexe", nullptr));
        QTableWidgetItem *___qtablewidgetitem25 = tableClients->horizontalHeaderItem(7);
        ___qtablewidgetitem25->setText(QCoreApplication::translate("MainWindow", "Actions", nullptr));
        QTableWidgetItem *___qtablewidgetitem26 = tableClients->horizontalHeaderItem(8);
        ___qtablewidgetitem26->setText(QCoreApplication::translate("MainWindow", "SMS", nullptr));

        const bool __sortingEnabled2 = tableClients->isSortingEnabled();
        tableClients->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem27 = tableClients->item(0, 0);
        ___qtablewidgetitem27->setText(QCoreApplication::translate("MainWindow", "1235", nullptr));
        QTableWidgetItem *___qtablewidgetitem28 = tableClients->item(0, 1);
        ___qtablewidgetitem28->setText(QCoreApplication::translate("MainWindow", "romdhani", nullptr));
        QTableWidgetItem *___qtablewidgetitem29 = tableClients->item(0, 2);
        ___qtablewidgetitem29->setText(QCoreApplication::translate("MainWindow", "khalil", nullptr));
        QTableWidgetItem *___qtablewidgetitem30 = tableClients->item(0, 3);
        ___qtablewidgetitem30->setText(QCoreApplication::translate("MainWindow", "20", nullptr));
        QTableWidgetItem *___qtablewidgetitem31 = tableClients->item(0, 4);
        ___qtablewidgetitem31->setText(QCoreApplication::translate("MainWindow", "Vip", nullptr));
        QTableWidgetItem *___qtablewidgetitem32 = tableClients->item(0, 5);
        ___qtablewidgetitem32->setText(QCoreApplication::translate("MainWindow", "97877212", nullptr));
        QTableWidgetItem *___qtablewidgetitem33 = tableClients->item(0, 6);
        ___qtablewidgetitem33->setText(QCoreApplication::translate("MainWindow", "homme", nullptr));
        QTableWidgetItem *___qtablewidgetitem34 = tableClients->item(0, 7);
        ___qtablewidgetitem34->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        QTableWidgetItem *___qtablewidgetitem35 = tableClients->item(1, 0);
        ___qtablewidgetitem35->setText(QCoreApplication::translate("MainWindow", "5997", nullptr));
        QTableWidgetItem *___qtablewidgetitem36 = tableClients->item(1, 1);
        ___qtablewidgetitem36->setText(QCoreApplication::translate("MainWindow", "ayari", nullptr));
        QTableWidgetItem *___qtablewidgetitem37 = tableClients->item(1, 2);
        ___qtablewidgetitem37->setText(QCoreApplication::translate("MainWindow", "ale", nullptr));
        QTableWidgetItem *___qtablewidgetitem38 = tableClients->item(1, 3);
        ___qtablewidgetitem38->setText(QCoreApplication::translate("MainWindow", "20", nullptr));
        QTableWidgetItem *___qtablewidgetitem39 = tableClients->item(1, 4);
        ___qtablewidgetitem39->setText(QCoreApplication::translate("MainWindow", "vip", nullptr));
        QTableWidgetItem *___qtablewidgetitem40 = tableClients->item(1, 5);
        ___qtablewidgetitem40->setText(QCoreApplication::translate("MainWindow", "546544689", nullptr));
        QTableWidgetItem *___qtablewidgetitem41 = tableClients->item(1, 6);
        ___qtablewidgetitem41->setText(QCoreApplication::translate("MainWindow", "Famme", nullptr));
        QTableWidgetItem *___qtablewidgetitem42 = tableClients->item(1, 7);
        ___qtablewidgetitem42->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        QTableWidgetItem *___qtablewidgetitem43 = tableClients->item(2, 0);
        ___qtablewidgetitem43->setText(QCoreApplication::translate("MainWindow", "5456", nullptr));
        QTableWidgetItem *___qtablewidgetitem44 = tableClients->item(2, 1);
        ___qtablewidgetitem44->setText(QCoreApplication::translate("MainWindow", "malouch", nullptr));
        QTableWidgetItem *___qtablewidgetitem45 = tableClients->item(2, 2);
        ___qtablewidgetitem45->setText(QCoreApplication::translate("MainWindow", "Eya", nullptr));
        QTableWidgetItem *___qtablewidgetitem46 = tableClients->item(2, 3);
        ___qtablewidgetitem46->setText(QCoreApplication::translate("MainWindow", "20", nullptr));
        QTableWidgetItem *___qtablewidgetitem47 = tableClients->item(2, 4);
        ___qtablewidgetitem47->setText(QCoreApplication::translate("MainWindow", "vip", nullptr));
        QTableWidgetItem *___qtablewidgetitem48 = tableClients->item(2, 5);
        ___qtablewidgetitem48->setText(QCoreApplication::translate("MainWindow", "3545466512", nullptr));
        QTableWidgetItem *___qtablewidgetitem49 = tableClients->item(2, 6);
        ___qtablewidgetitem49->setText(QCoreApplication::translate("MainWindow", "Famme", nullptr));
        QTableWidgetItem *___qtablewidgetitem50 = tableClients->item(2, 7);
        ___qtablewidgetitem50->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        tableClients->setSortingEnabled(__sortingEnabled2);

        btnListeClients_4->setText(QCoreApplication::translate("MainWindow", "Liste des clients", nullptr));
        btnAjouterClient_4->setText(QCoreApplication::translate("MainWindow", "Ajouter client", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "Statistiques", nullptr));
        label_2->setText(QString());
        label_3->setText(QString());
        lblFicheClient_3->setText(QCoreApplication::translate("MainWindow", "Fiche Client", nullptr));
        lblid_3->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        lblnom_4->setText(QCoreApplication::translate("MainWindow", "Nom", nullptr));
        lblprenom_3->setText(QCoreApplication::translate("MainWindow", "Pr\303\251nom", nullptr));
        lbltel_3->setText(QCoreApplication::translate("MainWindow", "Telephone", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "Sexe", nullptr));
        lblbirth_3->setText(QCoreApplication::translate("MainWindow", "Date de naissance", nullptr));
        lblstatus->setText(QCoreApplication::translate("MainWindow", "statut de fidelit\303\251", nullptr));
        btnConfirmer_3->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#2980b9;color:white;font-weight:bold;border-radius:15px;padding:8px 24px;font-size:15px;", nullptr));
        btnConfirmer_3->setText(QCoreApplication::translate("MainWindow", "Confirmer", nullptr));
        btnAnnuler_3->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#636e72;color:white;font-weight:bold;border-radius:15px;padding:8px 24px;font-size:15px;", nullptr));
        btnAnnuler_3->setText(QCoreApplication::translate("MainWindow", "Annuler", nullptr));
        lineEditNom_4->setText(QString());
        lineEditNom_4->setPlaceholderText(QCoreApplication::translate("MainWindow", "Nom", nullptr));
        lineEditPhone_3->setText(QString());
        lineEditPhone_3->setPlaceholderText(QCoreApplication::translate("MainWindow", "Phone Number", nullptr));
        checkNew_2->setText(QCoreApplication::translate("MainWindow", "New", nullptr));
        lineEditDateNaissance_4->setText(QString());
        lineEditDateNaissance_4->setPlaceholderText(QCoreApplication::translate("MainWindow", "Date de naissance", nullptr));
        lineEditID_3->setText(QString());
        lineEditID_3->setPlaceholderText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        lineEditPrenom_3->setText(QString());
        lineEditPrenom_3->setPlaceholderText(QCoreApplication::translate("MainWindow", "Pr\303\251nom", nullptr));
        checkOld_2->setText(QCoreApplication::translate("MainWindow", "Old", nullptr));
        checkVIP_2->setText(QCoreApplication::translate("MainWindow", "VIP", nullptr));
        comboSexe_2->setItemText(0, QCoreApplication::translate("MainWindow", "Homme", nullptr));
        comboSexe_2->setItemText(1, QCoreApplication::translate("MainWindow", "Femme", nullptr));

        comboSexe_2->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#41375f;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:15px;", nullptr));
        lblphoto->setText(QString());
        lblordo->setText(QCoreApplication::translate("MainWindow", "Ordonnance :", nullptr));
        lblpdp->setText(QCoreApplication::translate("MainWindow", "Photo de profil :", nullptr));
        lblordo_2->setText(QCoreApplication::translate("MainWindow", "Achats recents :", nullptr));
        btnAjouterClient_5->setText(QCoreApplication::translate("MainWindow", "Ajouter client", nullptr));
        btnListeClients_5->setText(QCoreApplication::translate("MainWindow", "Liste des clients", nullptr));
        lblListeClients_4->setText(QCoreApplication::translate("MainWindow", "Liste des Fournisseur", nullptr));
        toolButton_22->setText(QCoreApplication::translate("MainWindow", "Fournisseurs", nullptr));
        toolButton_23->setText(QCoreApplication::translate("MainWindow", "Produis", nullptr));
        toolButton_24->setText(QCoreApplication::translate("MainWindow", "Personnels", nullptr));
        toolButton_25->setText(QCoreApplication::translate("MainWindow", "Locaux", nullptr));
        toolButton_26->setText(QCoreApplication::translate("MainWindow", "Client", nullptr));
        searchLineEdit_4->setText(QCoreApplication::translate("MainWindow", "Recherche par Nom ou Email", nullptr));
        searchLineEdit_4->setPlaceholderText(QCoreApplication::translate("MainWindow", "Rechercher par ID ou Nom", nullptr));
        btnRechercher_4->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#a55eea;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:14px;", nullptr));
        btnRechercher_4->setText(QCoreApplication::translate("MainWindow", "Rechercher", nullptr));
        comboProfession_4->setItemText(0, QCoreApplication::translate("MainWindow", "Produit fournis", nullptr));
        comboProfession_4->setItemText(1, QCoreApplication::translate("MainWindow", "Statut", nullptr));
        comboProfession_4->setItemText(2, QCoreApplication::translate("MainWindow", "Nom de Fournisseur", nullptr));

        btnFilter_4->setText(QCoreApplication::translate("MainWindow", "Filter", nullptr));
        btnExporter_4->setText(QCoreApplication::translate("MainWindow", "Exporter ", nullptr));
        QTableWidgetItem *___qtablewidgetitem51 = tableClients_2->horizontalHeaderItem(0);
        ___qtablewidgetitem51->setText(QCoreApplication::translate("MainWindow", "ID Fournisseur", nullptr));
        QTableWidgetItem *___qtablewidgetitem52 = tableClients_2->horizontalHeaderItem(1);
        ___qtablewidgetitem52->setText(QCoreApplication::translate("MainWindow", "Nom Entreprise", nullptr));
        QTableWidgetItem *___qtablewidgetitem53 = tableClients_2->horizontalHeaderItem(2);
        ___qtablewidgetitem53->setText(QCoreApplication::translate("MainWindow", "Categorie", nullptr));
        QTableWidgetItem *___qtablewidgetitem54 = tableClients_2->horizontalHeaderItem(3);
        ___qtablewidgetitem54->setText(QCoreApplication::translate("MainWindow", "Delais", nullptr));
        QTableWidgetItem *___qtablewidgetitem55 = tableClients_2->horizontalHeaderItem(4);
        ___qtablewidgetitem55->setText(QCoreApplication::translate("MainWindow", "Num Tel", nullptr));
        QTableWidgetItem *___qtablewidgetitem56 = tableClients_2->horizontalHeaderItem(5);
        ___qtablewidgetitem56->setText(QCoreApplication::translate("MainWindow", "Addresse", nullptr));
        QTableWidgetItem *___qtablewidgetitem57 = tableClients_2->horizontalHeaderItem(6);
        ___qtablewidgetitem57->setText(QCoreApplication::translate("MainWindow", "Modif", nullptr));

        const bool __sortingEnabled3 = tableClients_2->isSortingEnabled();
        tableClients_2->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem58 = tableClients_2->item(0, 0);
        ___qtablewidgetitem58->setText(QCoreApplication::translate("MainWindow", "125", nullptr));
        QTableWidgetItem *___qtablewidgetitem59 = tableClients_2->item(0, 1);
        ___qtablewidgetitem59->setText(QCoreApplication::translate("MainWindow", "romdhani", nullptr));
        QTableWidgetItem *___qtablewidgetitem60 = tableClients_2->item(0, 2);
        ___qtablewidgetitem60->setText(QCoreApplication::translate("MainWindow", "Lunettes", nullptr));
        QTableWidgetItem *___qtablewidgetitem61 = tableClients_2->item(0, 3);
        ___qtablewidgetitem61->setText(QCoreApplication::translate("MainWindow", "No", nullptr));
        QTableWidgetItem *___qtablewidgetitem62 = tableClients_2->item(0, 4);
        ___qtablewidgetitem62->setText(QCoreApplication::translate("MainWindow", "97877212", nullptr));
        QTableWidgetItem *___qtablewidgetitem63 = tableClients_2->item(0, 5);
        ___qtablewidgetitem63->setText(QCoreApplication::translate("MainWindow", "Tunis-Hammamet", nullptr));
        QTableWidgetItem *___qtablewidgetitem64 = tableClients_2->item(1, 0);
        ___qtablewidgetitem64->setText(QCoreApplication::translate("MainWindow", "5862", nullptr));
        QTableWidgetItem *___qtablewidgetitem65 = tableClients_2->item(1, 1);
        ___qtablewidgetitem65->setText(QCoreApplication::translate("MainWindow", "ayari", nullptr));
        QTableWidgetItem *___qtablewidgetitem66 = tableClients_2->item(1, 2);
        ___qtablewidgetitem66->setText(QCoreApplication::translate("MainWindow", "accessoires", nullptr));
        QTableWidgetItem *___qtablewidgetitem67 = tableClients_2->item(1, 3);
        ___qtablewidgetitem67->setText(QCoreApplication::translate("MainWindow", "un peux ", nullptr));
        QTableWidgetItem *___qtablewidgetitem68 = tableClients_2->item(1, 4);
        ___qtablewidgetitem68->setText(QCoreApplication::translate("MainWindow", "546544689", nullptr));
        QTableWidgetItem *___qtablewidgetitem69 = tableClients_2->item(1, 5);
        ___qtablewidgetitem69->setText(QCoreApplication::translate("MainWindow", "France-paris", nullptr));
        QTableWidgetItem *___qtablewidgetitem70 = tableClients_2->item(1, 6);
        ___qtablewidgetitem70->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        QTableWidgetItem *___qtablewidgetitem71 = tableClients_2->item(2, 0);
        ___qtablewidgetitem71->setText(QCoreApplication::translate("MainWindow", "161532", nullptr));
        QTableWidgetItem *___qtablewidgetitem72 = tableClients_2->item(2, 1);
        ___qtablewidgetitem72->setText(QCoreApplication::translate("MainWindow", "malouch", nullptr));
        QTableWidgetItem *___qtablewidgetitem73 = tableClients_2->item(2, 2);
        ___qtablewidgetitem73->setText(QCoreApplication::translate("MainWindow", "lentilles", nullptr));
        QTableWidgetItem *___qtablewidgetitem74 = tableClients_2->item(2, 3);
        ___qtablewidgetitem74->setText(QCoreApplication::translate("MainWindow", "Tres retard", nullptr));
        QTableWidgetItem *___qtablewidgetitem75 = tableClients_2->item(2, 4);
        ___qtablewidgetitem75->setText(QCoreApplication::translate("MainWindow", "3545466512", nullptr));
        QTableWidgetItem *___qtablewidgetitem76 = tableClients_2->item(2, 5);
        ___qtablewidgetitem76->setText(QCoreApplication::translate("MainWindow", "Saudia-Al Riadh", nullptr));
        QTableWidgetItem *___qtablewidgetitem77 = tableClients_2->item(2, 6);
        ___qtablewidgetitem77->setText(QCoreApplication::translate("MainWindow", "...", nullptr));
        tableClients_2->setSortingEnabled(__sortingEnabled3);

        btnListeClients_6->setText(QCoreApplication::translate("MainWindow", "Liste des Fournisseurs", nullptr));
        btnAjouterClient_6->setText(QCoreApplication::translate("MainWindow", "Ajouter Fournisseur", nullptr));
        label_28->setText(QCoreApplication::translate("MainWindow", "Statistiques", nullptr));
        lblFicheClient_4->setText(QCoreApplication::translate("MainWindow", "Fiche Fournisseur", nullptr));
        lblid_4->setText(QCoreApplication::translate("MainWindow", "ID Fournisseur", nullptr));
        lblnom_5->setText(QCoreApplication::translate("MainWindow", "Nom De L'entreprise", nullptr));
        lblprenom_4->setText(QCoreApplication::translate("MainWindow", "Categorie", nullptr));
        lbltel_4->setText(QCoreApplication::translate("MainWindow", "Personne de contact", nullptr));
        lblbirth_4->setText(QCoreApplication::translate("MainWindow", "Adresse", nullptr));
        btnConfirmer_4->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#2980b9;color:white;font-weight:bold;border-radius:15px;padding:8px 24px;font-size:15px;", nullptr));
        btnConfirmer_4->setText(QCoreApplication::translate("MainWindow", "Confirmer", nullptr));
        btnAnnuler_4->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#636e72;color:white;font-weight:bold;border-radius:15px;padding:8px 24px;font-size:15px;", nullptr));
        btnAnnuler_4->setText(QCoreApplication::translate("MainWindow", "Annuler", nullptr));
        lineEditNom_5->setText(QString());
        lineEditNom_5->setPlaceholderText(QCoreApplication::translate("MainWindow", "Nom de L'Entreprise", nullptr));
        lineEditPhone_4->setText(QString());
        lineEditPhone_4->setPlaceholderText(QCoreApplication::translate("MainWindow", "Telephone", nullptr));
        lineEditDateNaissance_5->setText(QString());
        lineEditDateNaissance_5->setPlaceholderText(QCoreApplication::translate("MainWindow", "Adresse", nullptr));
        lineEditID_4->setText(QString());
        lineEditID_4->setPlaceholderText(QCoreApplication::translate("MainWindow", "ID Fournisseur", nullptr));
        comboCategorie->setItemText(0, QCoreApplication::translate("MainWindow", "Lunettes", nullptr));
        comboCategorie->setItemText(1, QCoreApplication::translate("MainWindow", "Lentilles", nullptr));
        comboCategorie->setItemText(2, QCoreApplication::translate("MainWindow", "Services", nullptr));
        comboCategorie->setItemText(3, QCoreApplication::translate("MainWindow", "Accessoires", nullptr));

        comboCategorie->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#41375f;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:15px;", nullptr));
        lineEditPhone_5->setText(QString());
        lineEditPhone_5->setPlaceholderText(QCoreApplication::translate("MainWindow", "Email", nullptr));
        lbltel_5->setText(QCoreApplication::translate("MainWindow", "Email", nullptr));
        btnAjouterClient_7->setText(QCoreApplication::translate("MainWindow", "Ajouter fournisseur", nullptr));
        btnListeClients_7->setText(QCoreApplication::translate("MainWindow", "Liste des fournisseurs", nullptr));
        lblListeClients_5->setText(QCoreApplication::translate("MainWindow", "Liste du Liste du Produit", nullptr));
        toolButton_27->setText(QCoreApplication::translate("MainWindow", "Fournisseurs", nullptr));
        toolButton_28->setText(QCoreApplication::translate("MainWindow", "Produis", nullptr));
        toolButton_29->setText(QCoreApplication::translate("MainWindow", "Personnels", nullptr));
        toolButton_30->setText(QCoreApplication::translate("MainWindow", "Locaux", nullptr));
        toolButton_31->setText(QCoreApplication::translate("MainWindow", "Client", nullptr));
        searchLineEdit_5->setPlaceholderText(QCoreApplication::translate("MainWindow", "Rechercher par ID ou Nom de Produit", nullptr));
        btnRechercher_5->setStyleSheet(QCoreApplication::translate("MainWindow", "background-color:#a55eea;color:white;font-weight:bold;border-radius:10px;padding:8px 16px;font-size:14px;", nullptr));
        btnRechercher_5->setText(QCoreApplication::translate("MainWindow", "Rechercher", nullptr));
        comboProfession_5->setItemText(0, QCoreApplication::translate("MainWindow", "Trie", nullptr));
        comboProfession_5->setItemText(1, QCoreApplication::translate("MainWindow", "Prix Bas", nullptr));
        comboProfession_5->setItemText(2, QCoreApplication::translate("MainWindow", "Prix Haut", nullptr));
        comboProfession_5->setItemText(3, QCoreApplication::translate("MainWindow", "A-Z", nullptr));
        comboProfession_5->setItemText(4, QCoreApplication::translate("MainWindow", "Z-A", nullptr));
        comboProfession_5->setItemText(5, QCoreApplication::translate("MainWindow", "Homme", nullptr));
        comboProfession_5->setItemText(6, QCoreApplication::translate("MainWindow", "Femme", nullptr));

        comboProfession_5->setCurrentText(QCoreApplication::translate("MainWindow", "Trie", nullptr));
        btnFilter_5->setText(QCoreApplication::translate("MainWindow", "Filter", nullptr));
        btnExporter_5->setText(QCoreApplication::translate("MainWindow", "Exporter ", nullptr));
        QTableWidgetItem *___qtablewidgetitem78 = tablePersonnel_3->horizontalHeaderItem(0);
        ___qtablewidgetitem78->setText(QCoreApplication::translate("MainWindow", "ID Produit", nullptr));
        QTableWidgetItem *___qtablewidgetitem79 = tablePersonnel_3->horizontalHeaderItem(1);
        ___qtablewidgetitem79->setText(QCoreApplication::translate("MainWindow", "Marque", nullptr));
        QTableWidgetItem *___qtablewidgetitem80 = tablePersonnel_3->horizontalHeaderItem(2);
        ___qtablewidgetitem80->setText(QCoreApplication::translate("MainWindow", "Mod\303\251le", nullptr));
        QTableWidgetItem *___qtablewidgetitem81 = tablePersonnel_3->horizontalHeaderItem(3);
        ___qtablewidgetitem81->setText(QCoreApplication::translate("MainWindow", "Type", nullptr));
        QTableWidgetItem *___qtablewidgetitem82 = tablePersonnel_3->horizontalHeaderItem(4);
        ___qtablewidgetitem82->setText(QCoreApplication::translate("MainWindow", "Couleur", nullptr));
        QTableWidgetItem *___qtablewidgetitem83 = tablePersonnel_3->horizontalHeaderItem(5);
        ___qtablewidgetitem83->setText(QCoreApplication::translate("MainWindow", "Prix", nullptr));
        QTableWidgetItem *___qtablewidgetitem84 = tablePersonnel_3->horizontalHeaderItem(6);
        ___qtablewidgetitem84->setText(QCoreApplication::translate("MainWindow", "Quantit\303\251", nullptr));
        QTableWidgetItem *___qtablewidgetitem85 = tablePersonnel_3->horizontalHeaderItem(7);
        ___qtablewidgetitem85->setText(QCoreApplication::translate("MainWindow", "Date d'ajout", nullptr));
        QTableWidgetItem *___qtablewidgetitem86 = tablePersonnel_3->horizontalHeaderItem(8);
        ___qtablewidgetitem86->setText(QCoreApplication::translate("MainWindow", "Actions", nullptr));

        const bool __sortingEnabled4 = tablePersonnel_3->isSortingEnabled();
        tablePersonnel_3->setSortingEnabled(false);
        tablePersonnel_3->setSortingEnabled(__sortingEnabled4);

        btnListePersonnel_5->setText(QCoreApplication::translate("MainWindow", "Liste du Produit", nullptr));
        btnAjouterPersonnel_5->setText(QCoreApplication::translate("MainWindow", "Ajouter Produit", nullptr));
        label_32->setText(QCoreApplication::translate("MainWindow", "Statistiques", nullptr));
        label_33->setText(QString());
        label_34->setText(QString());
        btnAjouterClient_8->setText(QCoreApplication::translate("MainWindow", "Ajouter Produit", nullptr));
        btnListeClients_8->setText(QCoreApplication::translate("MainWindow", "Liste du Produit", nullptr));
        label_29->setText(QCoreApplication::translate("MainWindow", "alerte", nullptr));
        label_18->setText(QString());
        QTableWidgetItem *___qtablewidgetitem87 = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem87->setText(QCoreApplication::translate("MainWindow", "ID Produit", nullptr));

        const bool __sortingEnabled5 = tableWidget->isSortingEnabled();
        tableWidget->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem88 = tableWidget->item(0, 0);
        ___qtablewidgetitem88->setText(QCoreApplication::translate("MainWindow", "2312", nullptr));
        QTableWidgetItem *___qtablewidgetitem89 = tableWidget->item(1, 0);
        ___qtablewidgetitem89->setText(QCoreApplication::translate("MainWindow", "6574", nullptr));
        QTableWidgetItem *___qtablewidgetitem90 = tableWidget->item(2, 0);
        ___qtablewidgetitem90->setText(QCoreApplication::translate("MainWindow", "7456", nullptr));
        QTableWidgetItem *___qtablewidgetitem91 = tableWidget->item(3, 0);
        ___qtablewidgetitem91->setText(QCoreApplication::translate("MainWindow", "0879", nullptr));
        QTableWidgetItem *___qtablewidgetitem92 = tableWidget->item(4, 0);
        ___qtablewidgetitem92->setText(QCoreApplication::translate("MainWindow", "2313", nullptr));
        tableWidget->setSortingEnabled(__sortingEnabled5);

        lblFicheClient_5->setText(QCoreApplication::translate("MainWindow", "Fiche Produit", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "ID Produit", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Marque", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "Mod\303\250le", nullptr));
        label_24->setText(QCoreApplication::translate("MainWindow", "Type", nullptr));
        label_25->setText(QCoreApplication::translate("MainWindow", "Prix public", nullptr));
        label_30->setText(QCoreApplication::translate("MainWindow", "Couleur", nullptr));
        btnAnnuler_5->setText(QCoreApplication::translate("MainWindow", "Annuler", nullptr));
        btnConfirmer_5->setText(QCoreApplication::translate("MainWindow", "Confirmer", nullptr));
        lineEditNom_6->setText(QString());
        lineEditNom_6->setPlaceholderText(QCoreApplication::translate("MainWindow", "Marque", nullptr));
        lineEditDateNaissance_6->setText(QString());
        lineEditDateNaissance_6->setPlaceholderText(QCoreApplication::translate("MainWindow", "Couleur", nullptr));
        lineEditID_5->setText(QString());
        lineEditID_5->setPlaceholderText(QCoreApplication::translate("MainWindow", "ID Produit", nullptr));
        lineEditPrenom_4->setText(QString());
        lineEditPrenom_4->setPlaceholderText(QCoreApplication::translate("MainWindow", "Mod\303\250le", nullptr));
        label_31->setText(QCoreApplication::translate("MainWindow", "Remise", nullptr));
        label_35->setText(QCoreApplication::translate("MainWindow", "Quantit\303\251", nullptr));
        lineEditDateNaissance_7->setText(QString());
        lineEditDateNaissance_7->setPlaceholderText(QCoreApplication::translate("MainWindow", "Prix public", nullptr));
        label_36->setText(QCoreApplication::translate("MainWindow", "Date d'ajout", nullptr));
        comboProfession_6->setItemText(0, QCoreApplication::translate("MainWindow", "Type", nullptr));
        comboProfession_6->setItemText(1, QCoreApplication::translate("MainWindow", "Solaire", nullptr));
        comboProfession_6->setItemText(2, QCoreApplication::translate("MainWindow", "Vue", nullptr));
        comboProfession_6->setItemText(3, QCoreApplication::translate("MainWindow", "Mixte", nullptr));
        comboProfession_6->setItemText(4, QCoreApplication::translate("MainWindow", "Lentille", nullptr));
        comboProfession_6->setItemText(5, QString());

        label_37->setText(QCoreApplication::translate("MainWindow", "Mati\303\250re", nullptr));
        comboProfession_7->setItemText(0, QCoreApplication::translate("MainWindow", "Choisir", nullptr));
        comboProfession_7->setItemText(1, QCoreApplication::translate("MainWindow", "plastique", nullptr));
        comboProfession_7->setItemText(2, QCoreApplication::translate("MainWindow", "m\303\251tal", nullptr));
        comboProfession_7->setItemText(3, QCoreApplication::translate("MainWindow", "titane", nullptr));

        comboProfession_8->setItemText(0, QCoreApplication::translate("MainWindow", "Choisir", nullptr));
        comboProfession_8->setItemText(1, QCoreApplication::translate("MainWindow", "Homme", nullptr));
        comboProfession_8->setItemText(2, QCoreApplication::translate("MainWindow", "Femme", nullptr));
        comboProfession_8->setItemText(3, QCoreApplication::translate("MainWindow", "Unisexe", nullptr));

        label_38->setText(QCoreApplication::translate("MainWindow", "Genre", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
