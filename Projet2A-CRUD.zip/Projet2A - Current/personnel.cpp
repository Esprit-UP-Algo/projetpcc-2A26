#include "personnel.h"

Personnel::Personnel() { /* default values */ }

Personnel::Personnel(int id, QString nom, QString prenom, QString mail, QString telephone, QString role, QString sexe)
{
    this->id = id;
    this->nom = nom;
    this->prenom = prenom;
    this->mail = mail;
    this->telephone = telephone;
    this->role = role;
    this->sexe = sexe;
}

bool Personnel::ajouter()
{
    QSqlQuery query;
    query.prepare("INSERT INTO PERSONNELS (ID, NOM, PRENOM, MAIL, TELEPHONE, ROLE, SEXE) "
                  "VALUES (:id, :nom, :prenom, :mail, :telephone, :role, :sexe)");

    query.bindValue(":id", id);
    query.bindValue(":nom", nom);
    query.bindValue(":prenom", prenom);
    query.bindValue(":mail", mail);
    query.bindValue(":telephone", telephone);
    query.bindValue(":role", role);
    query.bindValue(":sexe", sexe);

    return query.exec();
}

bool Personnel::supprimer(int id)
{
    QSqlQuery query;
    query.prepare("DELETE FROM PERSONNELS WHERE ID = :id");
    query.bindValue(":id", id);
    return query.exec();
}

QSqlQuery Personnel::afficher()
{
    QSqlQuery query;
    query.prepare("SELECT * FROM PERSONNELS");
    query.exec();
    return query;
}
