#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QHBoxLayout>
#include <QPushButton>
#include <QIcon>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Je renomme tablePersonnel en tablePersonnel pour correspondre à votre UI
    // Si votre objet s'appelle bien tablePersonnel, remettez-le.
    QTableWidget* tablePersonnel = ui->tablePersonnel;

    ui->stackedWidget->setCurrentIndex(0);

    // ... Vos connexions de navigation (inchangées) ...
    connect(ui->btnAjouterPersonnel_3, &QPushButton::clicked, [=]() { ui->stackedWidget->setCurrentIndex(2); });
    connect(ui->btnListePersonnel_3, &QPushButton::clicked, [=]() { ui->stackedWidget->setCurrentIndex(0); });
    connect(ui->btnAjouterClient_2, &QPushButton::clicked, [=]() { ui->stackedWidget->setCurrentIndex(2); });
    connect(ui->btnListeClients_2, &QPushButton::clicked, [=]() { ui->stackedWidget->setCurrentIndex(0); });


    // Configuration du tableau
    tablePersonnel->setRowCount(8);
    // Dans le constructeur MainWindow::MainWindow

    // --- MODIFICATION : Ajuster la largeur des NOUVELLES colonnes ---
    // Les indices de colonne commencent à 0, donc 7, 8, 9 sont les nouvelles.
    tablePersonnel->verticalHeader()->setDefaultSectionSize(45);


    // --- MODIFIÉ : Ajuster la largeur des colonnes pour les nouveaux boutons ---
    tablePersonnel->setColumnWidth(7, 60);  // Colonne "Documents" (assez pour 1 bouton)
    tablePersonnel->setColumnWidth(8, 60);  // Colonne "Permissions" (assez pour 1 bouton)
    tablePersonnel->setColumnWidth(9, 90);  // Colonne "Actions" (assez pour 2 boutons + espace)


    for (int row = 0; row < tablePersonnel->rowCount(); ++row) {
        // Crée une taille de bouton commune pour la cohérence
        QSize buttonSize(30, 30);
        QSize iconSize(20, 20);

        // --- Colonne 7 : DOCUMENTS (centré) ---
        // NOUVEAU : On crée un conteneur et un layout
        QWidget *docsWidget = new QWidget();
        QHBoxLayout *docsLayout = new QHBoxLayout(docsWidget);
        docsLayout->setContentsMargins(0, 0, 0, 0); // Pas de marges intérieures
        docsLayout->setAlignment(Qt::AlignCenter); // <-- LA LIGNE MAGIQUE !

        QPushButton *btnDocs = new QPushButton();
        btnDocs->setFlat(true);
        btnDocs->setFixedSize(buttonSize);
        btnDocs->setIcon(QIcon(":/icons/clip.png"));
        btnDocs->setIconSize(iconSize);
        btnDocs->setToolTip("Gérer les documents");
        btnDocs->setStyleSheet("QPushButton { background-color: #5D6D7E; border-radius: 8px; border: none; } QPushButton:hover { background-color: #85929E; }");

        docsLayout->addWidget(btnDocs); // On ajoute le bouton au layout
        tablePersonnel->setCellWidget(row, 7, docsWidget); // On ajoute le conteneur à la cellule


        // --- Colonne 8 : PERMISSIONS (centré) ---
        // NOUVEAU : On répète le même schéma de conteneur
        QWidget *permsWidget = new QWidget();
        QHBoxLayout *permsLayout = new QHBoxLayout(permsWidget);
        permsLayout->setContentsMargins(0, 0, 0, 0);
        permsLayout->setAlignment(Qt::AlignCenter); // <-- Centrage

        QPushButton *btnPerms = new QPushButton();
        btnPerms->setFlat(true);
        btnPerms->setFixedSize(buttonSize);
        btnPerms->setIcon(QIcon(":/icons/shield.png"));
        btnPerms->setIconSize(iconSize);
        btnPerms->setToolTip("Gérer les permissions");
        btnPerms->setStyleSheet("QPushButton { background-color: #884EA0; border-radius: 8px; border: none; } QPushButton:hover { background-color: #AF7AC5; }");

        permsLayout->addWidget(btnPerms);
        tablePersonnel->setCellWidget(row, 8, permsWidget);


        // --- Colonne 9 : ACTIONS (centré) ---
        QWidget *actionsWidget = new QWidget();
        QHBoxLayout *actionsLayout = new QHBoxLayout(actionsWidget);
        actionsLayout->setContentsMargins(0, 0, 0, 0);
        actionsLayout->setSpacing(8);
        actionsLayout->setAlignment(Qt::AlignCenter); // <-- On ajoute le centrage ici aussi

        QPushButton *btnModif = new QPushButton();
        btnModif->setFlat(true);
        btnModif->setFixedSize(buttonSize);
        btnModif->setIcon(QIcon(":/icons/pencil.png"));
        btnModif->setIconSize(iconSize);
        btnModif->setToolTip("Modifier l'employé");
        btnModif->setStyleSheet("QPushButton { background-color: rgb(0, 0, 124); border-radius: 8px; border: none; } QPushButton:hover { background-color: #2980b9; }");

        QPushButton *btnSupp = new QPushButton();
        btnSupp->setFlat(true);
        btnSupp->setFixedSize(buttonSize);
        btnSupp->setIcon(QIcon(":/icons/trash.png"));
        btnSupp->setIconSize(iconSize);
        btnSupp->setToolTip("Supprimer l'employé");
        btnSupp->setStyleSheet("QPushButton { background-color: #cd6155; border-radius: 8px; border: none; } QPushButton:hover { background-color: #c0392b; }");

        actionsLayout->addWidget(btnModif);
        actionsLayout->addWidget(btnSupp);
        tablePersonnel->setCellWidget(row, 9, actionsWidget);
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}
